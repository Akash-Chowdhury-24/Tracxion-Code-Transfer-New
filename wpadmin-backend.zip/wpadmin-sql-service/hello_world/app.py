import json
import crate_db_operation as opr_db_opr
import logging
import urllib3
logger = logging.getLogger()
logger.setLevel(logging.INFO)
# import requests


def lambda_handler(event, context):

    logger.info(f"Event==== {event}")
    print(f"Event Type {type(event)}")
    print("----------------------------")
    logger.info(context)
    message_body = event["Records"][0]["body"]
    print(f"type====== {type(message_body)}")
    print(f"messagebody===== {message_body}")
    if not isinstance(message_body, dict):
        message_body = json.loads(message_body)
    
    message_id=message_body['messageId']
    opr_db_opr.insert_messages(message_body,message_id)
    logger.info(message_body)
    logger.info("Message inserted successfully.")
    # TODO implement
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }

    # return {
    #     "statusCode": 200,
    #     "body": json.dumps({
    #         "message": "hello world",
    #         # "location": ip.text.replace("\n", "")
    #     }),
    # }

if __name__ == "__main__":
    # event = {
    #     "Records": [
    #         {
    #             "messageId": "269fa32a-2e44-418d-a0c8-2b8b7db047e8",
    #             "receiptHandle": "AQEBD4SXwZBBGPTKGlDRHAsJRPmm+ZanaQOxjLs2wBFpauCVnW8z66PZWfFrrGO5Dng6zFlI22r5eewQys3/E7qkkIvcuXJJnIq3HU8LTGIkKr7PDrAGFp3tVEemSIdyKkivcyzqgGyBP+0RZ/otJGQtGYigDD4ecTseRSENpgZkLGXSjvvzWyGEwrlaSyKm4Ttu0zk/SlqvCktLmwRmKQc7FhCauYHP9CARSMS3CTistbRk9fpVaaoA/uwI8zELcVtd6V/d247pZaSvywAjvHnbSmsqmrVtBmIk2Bsy09MqW55buhHXjKIFMNXBpIXmfh8tV7EaJKIzMwi2pK5sBrm9N3Y6dl1WHZkPzqsVGFxkJAbMms6v6hM2kqmnRLPi6UJsdQ+XIdzPB0m5p0EQ+EChL4r+vF8P9D927omWwelEH4o=",
    #             "body": "{\"sentiment\": \"POSITIVE\", \"sentiment_score\": {\"Positive\": 0.9798932075500488, \"Negative\": 0.001569646643474698, \"Neutral\": 0.017489861696958542, \"Mixed\": 0.0010473696747794747}, \"entities\": [\"Smith\"], \"user_text\": \"Another text.\"}",
    #             "attributes": {
    #                 "ApproximateReceiveCount": "1",
    #                 "AWSTraceHeader": "Root=1-6934417d-5b74cc5b61d8869e1d84e6c2;Parent=655ed4b088598d57;Sampled=0;Lineage=1:3c5660d5:0",
    #                 "SentTimestamp": "1765032321083",
    #                 "SenderId": "AROA4G36BONNIGNUOEA2C:wpadminmod-dev",
    #                 "ApproximateFirstReceiveTimestamp": "1765032322083",
    #             },
    #             "messageAttributes": {},
    #             "md5OfBody": "7bb71f417310e390c3ba40f8a9cc5ad8",
    #             "eventSource": "aws:sqs",
    #             "eventSourceARN": "arn:aws:sqs:ap-south-1:839393571674:wpadmintraxsionsqsservice",
    #             "awsRegion": "ap-south-1",
    #         }
    #     ]
    # }

    event= {
            "Records": [
                {
                "messageId": "a901a515-45ff-4b1b-b8bf-ad3824dedeab",
                "receiptHandle": "AQEBWsWkGPxpft1sdaG9G5AW9eIW87lbEGMjV43PAd/OODubLIT4hUsVmoQ2ojFwAVve8WYbS4t3zG07jUFqX/WsNjymcshsPMuY7CndnAqa1WYjoWz0t6SyUuY1XKu6Mpr1Pxt8EtHml7a49/j+fkDhWXoJORn677oBREfZXh6Nlbee5qpBeV+8Mv18+JF5+BdWiO7LZOx7SeGMczVVZkpmaXmZFugnrREhyfx7UgMjOubeSyVTker6rvuiPcI0s8LExViLPS4ur4sA5hhTkMVnnvBy9d5vTfsqhhG3b9Lkxeh2mAFd/wJN2fVJDM07AZkroiErdZM38fGfuhpo4nJ5hd8TIOShAvF9FQeISthpAwK35jEaNZK2/WyMLLDh8d1k3Z2qsNc+9qOs0swXTUzAYcaC6upMu7yBDFTE5Jd109U=",
                "body": {
                    "sentiment": "NEUTRAL",
                    "sentiment_score": {
                    "Positive": 0.001098338863812387,
                    "Negative": 0.0009800896514207125,
                    "Neutral": 0.9978107810020447,
                    "Mixed": 0.00011089296458521858
                    },
                    "entities": [],
                    "user_text": "Is this contact number +121212121 correct?",
                    "messageId": "afd1e20f-0d99-4b27-8198-ccf5000369d8",
                    "id": "null",
                    "customer_contact_number": "11132",
                    "agent_id": "DiscoDancer112",
                    "empresa_id": "1112"
                },
                "attributes": {
                    "ApproximateReceiveCount": "1",
                    "AWSTraceHeader": "Root=1-6950b05f-2b329d29439cbdf304ff6936;Parent=30669c106b3bb1ee;Sampled=0;Lineage=1:3c5660d5:0",
                    "SentTimestamp": "1766895711879",
                    "SenderId": "AROA4G36BONNIGNUOEA2C:wpadminmod-dev",
                    "ApproximateFirstReceiveTimestamp": "1766895712879"
                },
                "messageAttributes": {},
                "md5OfBody": "120b9309fa0cc8da8398b68529c6a490",
                "eventSource": "aws:sqs",
                "eventSourceARN": "arn:aws:sqs:ap-south-1:839393571674:wpadmintraxsionsqsservice",
                "awsRegion": "ap-south-1"
                }
            ]
        }

    context =""
    lambda_handler(event=event, context=context)