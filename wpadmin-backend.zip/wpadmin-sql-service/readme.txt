sam build
sam deploy --guided --no-fail-on-empty-changeset --stack-name wpadmin-sql-service

sam deploy --guided --force-upload

source venv/bin/activate
pip install -r requirements.txt -t python/lib/python3.x/site-packages/.



