import boto3

sqs = boto3.client("sqs", region_name="ap-south-1")

QUEUE_URL = "https://sqs.ap-south-1.amazonaws.com/*****/wpadmintraxsionsqsservice"
#sqs_url=os.environ.get('SQS_QUERY_URL', 'https://sqs.ap-south-1.amazonaws.com/839393571674/wpadmintraxsionsqsservice')

while True:
    response = sqs.receive_message(
        QueueUrl=QUEUE_URL,
        MaxNumberOfMessages=10,      # max allowed
        WaitTimeSeconds=20,          # long polling
        VisibilityTimeout=60         # time to process message
    )

    messages = response.get("Messages", [])
    print(messages)
    
    if not messages:
        print("Queue is empty")
        break

    for message in messages:
        body = message["Body"]
        receipt_handle = message["ReceiptHandle"]

        print("Processing:", body)

        # ✅ After successful processing, delete message
        sqs.delete_message(
            QueueUrl=QUEUE_URL,
            ReceiptHandle=receipt_handle
        )
