source venv/bin/activate
pip install -r requirements.txt -t python/lib/python3.x/site-packages/.

pip install --upgrade urllib3 botocore chalice
du -h .chalice/deployments/
chalice local
chalice package out/
chalice deploy --force