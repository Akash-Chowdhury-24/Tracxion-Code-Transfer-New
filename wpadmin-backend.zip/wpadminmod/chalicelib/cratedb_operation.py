import json
import threading
import time
import datetime

from urllib3.exceptions import ConnectTimeoutError, ReadTimeoutError
import urllib3
from crate import client
import math
import string
import logging

from websockets import connect

#from tests.all_genesys_agent_ids import agent_id

logger = logging.getLogger()
logger.setLevel(logging.INFO)
import redis

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)
def create_crate_connection():
    return client.connect(
        servers=[""],
        username="",
        password= "",
        timeout=urllib3.Timeout(connect=5.0,read=10.0),
        schema="crate",
        verify_ssl_cert=True,
    )

def create_redis_connection():
    logger.info("Getting Redis Connection Pool")
    redis_pool = redis.ConnectionPool(
        host='',
        port=12391,
        password="",
        db=0,
        username="",
        max_connections=10,  # keep small for Lambda
        socket_connect_timeout=2,
        socket_timeout=2,
        decode_responses=True  # returns str instead of bytes
    )
    redis_client = redis.Redis(connection_pool=redis_pool)
    return redis_client

class SentimentAnalysis:
    def __init__(self):
        logger.info("Initiating Sentiment Analysis")


    # ------------------------AWS Comprehend-----------------------

    def insert_message(message_id, chat_id, sender_id, sentiment, entities,
                       content=None, media_url=None,
                       message_type="text", status="sent",
                       ts=None):
        if ts is None:
            ts = datetime.utcnow()
        #crate.messages

        params = (
            message_id,
            chat_id,
            sender_id,
            content,
            media_url,
            message_type,
            status,
            sentiment,
            entities,
            ts
        )
        conn = pool.acquire(timeout=5)
        try:

            cursor=conn.cursor()
            crate_schema_name = cursor.connection.client.schema
            sql = f"""
                        INSERT INTO {crate_schema_name}.messages (
                            message_id, chat_id, sender_id,
                            content, media_url, message_type,
                            status, timestamp
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """
            cursor.execute(sql, params)
            logger.info("added message details successfully.")
        except ConnectTimeoutError:
            logger.error(f"Error occur when inserting messages details ")
        except ReadTimeoutError:
            logger.info('Read timeout: server did not respond within timeout period')
        except Exception as e:
            logger.info(f"{e}")
        finally:
            logger.info("closing connection.")
            pool.release(conn)

    def add_participant(chat_id, user_id, role="member"):
        try:
            conn = pool.acquire(timeout=5)
            cursor = conn.cursor()
            crate_schema_name = cursor.connection.client.schema
            sql = f"""
                INSERT INTO {crate_schema_name}.chat_participants (
                    chat_id, user_id, role, joined_at
                ) VALUES (?, ?, ?, ?)
            """
            params = (
                chat_id,
                user_id,
                role,  # 'member' or 'admin'
                datetime.utcnow()
            )
            cursor.execute(sql, params)
        except ConnectTimeoutError:
            logger.error(f"Error occur when inserting company details ")
        except ReadTimeoutError:
            logger.info('Read timeout: server did not respond wihtin timeout period')
        except Exception as e:
            logger.info(f"{e}")
        finally:
            pool.release(conn)

    def insert_chat(chat_id, chat_type, name=None, group_picture=None):
        try:
            conn = pool.acquire(timeout=10)
            cursor = conn.cursor()
            crate_schema_name = cursor.connection.client.schema
            sql = f"""
                INSERT INTO {crate_schema_name}.chats (
                    chat_id, chat_type, name, group_picture, created_at
                ) VALUES (?, ?, ?, ?, ?)
            """
            params = (
                chat_id,
                chat_type,  # 'private' or 'group'
                name,
                group_picture,
                datetime.utcnow()
            )
            cursor.execute(sql, params)
        except ConnectTimeoutError:
            logger.error(f"Error occur when inserting company details ")
        except ReadTimeoutError:
            logger.info('Read timeout: server did not respond wihtin timeout period')
        except Exception as e:
            logger.info(f"{e}")
        finally:
            pool.release(conn)

    def insert_user(user_id, phone_number, username, profile_picture=None,
                    status=None, last_seen=None):

        try:
            conn = pool.acquire(timeout=10)
            cursor = conn.cursor()
            sql = f"""
                    INSERT INTO users (
                        user_id, phone_number, username,
                        profile_picture, status, last_seen, created_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?)
                """
            params = (
                user_id,
                phone_number,
                username,
                profile_picture,
                status,
                last_seen,
                datetime.utcnow()
            )
            cursor.execute(sql, params)
        except Exception as e:
            logger.info(e)

    # -------------------------------------------------------------
class RedisConnectionPool:
    def __init__(self, creator):
        self._creator = creator
        self._pool = []
        self._in_use = set()

    def acquire(self,timeout=None):
        client=self._creator()
        self._in_use.add(client)
        return client

class SimpleConnectionPool:
    def __init__(self, creator, maxsize=10, **param):
        self._creator = creator
        self._maxsize=maxsize
        self._lock=threading.Lock()
        self._pool = []
        self._in_use = set()
        self._param=param



    def encrypt(self, unencrypted_text, key):
        # Define character groups
        lower = string.ascii_lowercase
        upper = string.ascii_uppercase
        digits = string.digits
        specials = string.punctuation
        all_symbols = lower + upper + digits + specials

        key_sum = sum(ord(c) for c in key)  # derive a numeric key for shifting

        encrypted = ''
        for c in unencrypted_text:
            if c in all_symbols:
                idx = all_symbols.index(c)
                # Deterministic (but not secure) shift
                e_idx = (idx + key_sum) % len(all_symbols)
                encrypted += all_symbols[e_idx]
            else:
                encrypted += c  # leave other chars unchanged
        return encrypted

    def decrypt(self, text, key):
        lower = string.ascii_lowercase
        upper = string.ascii_uppercase
        digits = string.digits
        specials = string.punctuation
        all_symbols = lower + upper + digits + specials

        key_sum = sum(ord(c) for c in key)

        decrypted = ''
        for c in text:
            if c in all_symbols:
                idx = all_symbols.index(c)
                d_idx = (idx - key_sum) % len(all_symbols)
                decrypted += all_symbols[d_idx]
            else:
                decrypted += c
        return decrypted

    def acquire(self, timeout=None):
        end_time=None
        if timeout is not None:
            logger.info(f"timeout {timeout}")
            end_time=time.time() + timeout

        while True:
            with self._lock:
                if self._pool:
                    conn = self._pool.pop()
                    self._in_use.add(id(conn))
                    logger.info("Return connection from step 1")
                    return conn

                if len(self._in_use) < self._maxsize:
                    conn = self._creator()
                    self._in_use.add(id(conn))
                    logger.info("Return connection from step 2")
                    return conn
            logger.info(f"Backup connection size {len(self._pool)}")
            if end_time is not None and time.time() > end_time and len(self._pool)==1:
                logger.info(f"End time {end_time}")
                logger.info(f"Current time {time.time()}")
                raise TimeoutError("Connection pool timeout")
            time.sleep(0.01)

    def release(self, conn):
        with self._lock:
            self._in_use.discard(id(conn))
            self._pool.append(conn)

    def close_all(self):
        with self._lock:
            for conn in list(self._pool):
                try:
                    conn.close()
                finally:
                    self._pool.remove(conn)
            for cid in list(self._in_use):
                # We may need a way to map id->connection; implement if available
                pass

#Usages
param='qmark'
pool = SimpleConnectionPool(create_crate_connection, maxsize=8, param=param)
print("CrateDB is ready")
redis_pool_obj=RedisConnectionPool(create_redis_connection)
if redis_pool_obj is None:
    print("No Redis connection")
else:
    print("FFFF")
print('Db connection executed.')
def check_login_of_user(userid, unencrypted_text, module_name, key):
    try:
        conn = pool.acquire(timeout=10)
        encrypted_string=pool.encrypt(unencrypted_text=unencrypted_text, key=key)
        logger.info(encrypted_string)
        cursor = conn.cursor()
        crate_schema_name = cursor.connection.client.schema
        sql=f"""SELECT userid, pass FROM {crate_schema_name}.LOGIN_MOD WHERE userid=? AND pass=? AND is_active=?"""
        cursor.execute(sql, (userid, encrypted_string, True,))
        user_details=cursor.fetchall()
        logger.info(user_details)
        return user_details
    except ConnectTimeoutError:
        logger.error(f"Error occur when inserting company details ")
    except ReadTimeoutError:
        logger.info('Read timeout: server did not respond wihtin timeout period')
    except Exception as e:
        logger.info(f"{e}")
    finally:
        pool.release(conn)

def  perform_corn_for_individual_staff(record_name, operation_type, user_id):
    try:
        conn = pool.acquire(timeout=5)
        cursor = conn.cursor()
        crate_schema_name = cursor.connection.client.schema
        # E-Edit, V-View, #D-Delete
        if operation_type == 'E' or operation_type == 'V':
            # sql=f"""SELECT staff_first_name, staff_last_name, staff_email, staff_phone, staff_role,staff_departmant, staff_id,staff_logo_url
            #         FROM {crate_schema_name}.STAFF_DETAILS WHERE staff_id='AUTOGENERATESTAFFID';"""
            sql = f"""SELECT staff_first_name, staff_last_name, staff_email, staff_phone, staff_role,staff_departmant, staff_id,staff_logo_url 
                                FROM {crate_schema_name}.STAFF_DETAILS WHERE staff_id=?;"""
            cursor.execute(sql, (record_name,))

            staff_details = [
                {
                    "staff_first_name": row[0],
                    "staff_last_name": row[1],
                    "staff_email": row[2],
                    "staff_phone": row[3],
                    "staff_role": row[4],
                    "staff_department": row[5],
                    "staff_id": row[6],  # fixed typo here
                    "staff_logo_url": row[7]
                }
                for row in cursor.fetchall()
            ]
            return staff_details
        elif operation_type=='D':
            from datetime import datetime, timezone
            utc = datetime.now(timezone.utc)
            sql=f"""UPDATE {crate_schema_name}.STAFF_DETAILS  set is_active=? AND update_by=? AND update_at=? WHERE staff_id=?"""
            cursor.execute(sql, (False, user_id, utc, record_name,))
            dele_tow = cursor.rowcount
            staff_details = [
                {"staff_id": record_name, "deleted": True, "deleted_by": user_id, "deletion_time": str(utc),
                 "num_of_rows": dele_tow}]
            return staff_details

    except ConnectTimeoutError:
        logger.error(f"Error occur when inserting company details ")
    except ReadTimeoutError:
        logger.info('Read timeout: server did not respond with in timeout period')
    except Exception as e:
        logger.info(f"{e}")
    finally:
        pool.release(conn)

def perform_corn_for_individual_company(record_name, operation_type, user_id):
    try:
        conn = pool.acquire(timeout=5)
        cursor = conn.cursor()
        crate_schema_name = cursor.connection.client.schema
        # E-Edit, V-View, #D-Delete
        if operation_type=='E' or operation_type=='V':
            sql=f"""SELECT company_name, company_owner_first_name, company_owner_last_name, company_email,
                 company_contact_number,company_city_nm, company_st_nm, company_zp_cd, company_logo_url 
                 FROM {crate_schema_name}.COMPANY_DETAILS WHERE company_id=?"""
            cursor.execute(sql, (record_name,))
            company_details = [
                {
                    "company_name": row[0],
                    'company_owner_first_name': row[1],
                    "company_owner_last_name": row[2],
                    'company_email': row[3],
                    'company_contact_number': row[4],
                    'company_city_nm': row[5],
                    'company_st_nm': row[6],
                    'company_zp_cd': row[7],
                    'company_logo_url': row[8]
                 }
                for row in cursor.fetchall()]
            return company_details
        elif operation_type=='D':
            logger.info("Initiating Delete operation.")
            from datetime import datetime, timezone
            utc = datetime.now(timezone.utc)
            sql=f"""UPDATE {crate_schema_name}.COMPANY_DETAILS SET is_active=? AND update_by=? AND update_at=? WHERE company_name=?"""
            cursor.execute(sql, (False, user_id, utc,record_name,))
            dele_tow=cursor.rowcount
            company_details = [{"company_name": record_name, "deleted": True, "deleted_by":user_id, "deletion_time": str(utc),"num_of_rows":dele_tow}]
            return company_details
    except ConnectTimeoutError:
        logger.error(f"Error occur when inserting company details ")
    except ReadTimeoutError:
        logger.info('Read timeout: server did not respond wihtin timeout period')
    except Exception as e:
        logger.info(f"{e}")
    finally:
        pool.release(conn)


def get_all_staffs(page, page_size, offset,where_clause, params, category):
    try:
        conn = pool.acquire(timeout=5)
        cursor = conn.cursor()
        crate_schema_name = cursor.connection.client.schema
        sql=f"""select CONCAT(staff_first_name,' ', staff_last_name) as STAFF_NAME, staff_departmant as DEPARTMENT, staff_email as EMAIL, staff_phone as PHONE, staff_logo_url, staff_id
                FROM {crate_schema_name}.STAFF_DETAILS {where_clause} ORDER BY staff_first_name ASC LIMIT ? OFFSET ?"""

        params.extend([page_size, offset])

        cursor.execute(sql, params)
        company_details = [ {"staff_name": row[0], 'department': row[1], "email" : row[2], 'phone': row[3],'staff_image': row[4], "staff_id": row[5]}
                            for row in cursor.fetchall() ]
        count_sql = f"""SELECT count(*) FROM {crate_schema_name}.STAFF_DETAILS {where_clause}"""
        cursor.execute(count_sql, params[:2] if category else [])
        total=cursor.fetchone()[0]
        logger.info(f"Record count {total}")

        return {
            "staff_details" : company_details,
            "page": page,
            "page_size": page_size,
            "total" : total,
            "total_page" : math.ceil(total / page_size),
            "status" : 200
        }
    except ConnectTimeoutError:
        logger.error(f"Error occur when inserting company details ")
    except ReadTimeoutError:
        logger.info('Read timeout: server did not respond wihtin timeout period')
    except Exception as e:
        logger.info(f"{e}")
    finally:
        pool.release(conn)

def get_all_companies(page, page_size, offset,where_clause, params, category):
    try:
        conn = pool.acquire(timeout=5)
        cursor = conn.cursor()
        crate_schema_name = cursor.connection.client.schema
        sql = f"""SELECT company_name, CONCAT(company_owner_first_name, ' ', company_owner_last_name) as POC, company_email, company_contact_number, company_logo_url, company_id
        FROM {crate_schema_name}.COMPANY_DETAILS {where_clause} ORDER BY company_name ASC LIMIT ? OFFSET ?"""

        params.extend([page_size, offset])

        cursor.execute(sql, params)
        company_details = [ {"company_name": row[0], 'POC': row[1], "email" : row[2], 'phone': row[3], 'company_logo': row[4], "company_id": row[5]}
                            for row in cursor.fetchall() ]
        count_sql = f"""SELECT count(*) FROM {crate_schema_name}.COMPANY_DETAILS {where_clause}"""
        cursor.execute(count_sql, params[:2] if category else [])
        total=cursor.fetchone()[0]
        logger.info(f"Record count {total}")

        return {
            "company_details" : company_details,
            "page": page,
            "page_size": page_size,
            "total" : total,
            "total_page" : math.ceil(total / page_size),
            "status" : 200
        }
    except ConnectTimeoutError:
        logger.error(f"Error occur when inserting company details ")
    except ReadTimeoutError:
        logger.info('Read timeout: server did not respond wihtin timeout period')
    except Exception as e:
        logger.info(f"{e}")
    finally:
        pool.release(conn)


def edit_new_working_hours(data):
    conn = pool.acquire(timeout=5)
    try:
        logger.info(f"Initiating working hours process.")
        from datetime import datetime, timezone
        utc = datetime.now(timezone.utc)
        weekly_hours = data['schedule'] #Weekly hours
        holiday_list = data['holidays'] # holiday details
        user_id = data['user']


        cursor = conn.cursor()
        crate_schema_name = cursor.connection.client.schema

        if len(weekly_hours)>0:
            #Start inserting Weekly times.
            monday=weekly_hours['monday']
            tuesday=weekly_hours['tuesday']
            wednesday=weekly_hours['wednesday']
            thursday=weekly_hours['thursday']
            friday=weekly_hours['friday']
            saturday=weekly_hours['saturday']
            sunday=weekly_hours['sunday']
            monday_t=('MONDAY', monday['start'], monday['end'], True, False,user_id,utc )
            tuesday_t = ('TUESDAY', tuesday['start'], tuesday['end'], True, False, user_id, utc)
            wednesday_t = ('WEDNESDAY', wednesday['start'], wednesday['end'], True, False, user_id, utc)
            thursday_t = ('THRUSDAY', thursday['start'], thursday['end'], True, False, user_id, utc)
            friday_t=('FRIDAY', friday['start'], friday['end'], True, False, user_id, utc)
            saturday_t=('SATURDAY', saturday['start'], saturday['end'], True, False, user_id, utc)
            sunday_t=('SUNDAY', sunday['start'], sunday['end'], True, False, user_id, utc)
            weeks=[]
            weeks.append(monday_t)
            weeks.append(tuesday_t)
            weeks.append(wednesday_t)
            weeks.append(thursday_t)
            weeks.append(friday_t)
            weeks.append(saturday_t)
            weeks.append(sunday_t)
            sql_weekly_hours=f"""INSERT INTO {crate_schema_name}.WORKING_LIST_DET (NAME_OF_DAY, START_AT, END_AT, WORKING_DAY, ANNUAL_HOLIDAY, UPDATE_BY, UPDATE_AT) VALUES (?,?,?,?,?,?,?)"""
            cursor.executemany(sql_weekly_hours, weeks)
            logger.info("Working list is updated successfully.")


        if len(holiday_list)>0:
            # Start inserting holiday list
            logger.info("Starting inserting Holiday list.")
            name=holiday_list['name']
            holiday_date = holiday_list['date']
            all_department_boolean=holiday_list['assignment_department']['all_department']
            select_department_boolean= holiday_list['assignment_department']['select_department']
            #A=All Department
            #S="Selected Department
            if select_department_boolean:
                department_name=holiday_list['assignment_department']['department_name']
                select_department='S'
            else:
                department_name = ""
                select_department='A'

            cursor.execute(f"""SELECT COALESCE(MAX(ID), 0) + 1 FROM {crate_schema_name}.HOLIDAY_LIST""")
            next_id = cursor.fetchone()[0]
            sql_holiday=f"""INSERT INTO {crate_schema_name}.HOLIDAY_LIST (ID, HOLIDAY_NAME, HOLIDAY_DATE, ASSIGNEMENT_DEPT, DEPARTMENT, USER_ID, INSERTED_AT) VALUES (?,?,?,?,?,?,?)"""
            cursor.execute(sql_holiday, (next_id, name, holiday_date, select_department, department_name, user_id, utc))
            logger.info("a")
        logger.info("Updating workings hours and holiday list is completed.")
    except ConnectTimeoutError:
        logger.error(f"Error occur when inserting company details ")
    except ReadTimeoutError:
        logger.info('Read timeout: server did not respond wihtin timeout period')
    except Exception as e:
        logger.info(f"{e}")
    finally:
        pool.release(conn)

def insert_new_staff_details(data):
    conn = pool.acquire(timeout=5)
    try:
        from datetime import datetime, timezone
        utc = datetime.now(timezone.utc)
        cursor = conn.cursor()
        crate_schema_name = cursor.connection.client.schema

        sql_update_company = f"""SELECT count(*) from {crate_schema_name}.STAFF_DETAILS"""
        cursor.execute(sql_update_company)
        res = cursor.fetchall()[0]
        staff_id = data['first_name'][:3] + str(utc.month) + str(utc.year) + str(utc.day) + str(res[0]+1)

        sql_staff=f"""INSERT INTO {crate_schema_name}.STAFF_DETAILS (STAFF_FIRST_NAME, STAFF_LAST_NAME, STAFF_EMAIL,STAFF_PHONE,
        STAFF_ROLE,STAFF_DEPARTMANT, STAFF_ID,STAFF_LOGO_URL, UPDATE_BY,UPDATE_AT,MODULE_NAME, IS_ACTIVE) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)"""
        #staff_id='AUTOGENERATESTAFFID'
        if 'update_by' not in data:
            update_by='NeedToUpdateInRequestBody'
        else:
            update_by=data['update_by']
        update_at=utc
        if 'module' not in data:
            module_name="NeedToUpdateInRequestBody"
        else:
            module_name=data['module']
        is_active=True
        result=cursor.execute(sql_staff, (data['first_name'], data['last_name'], data['email'], data['phone'],
                                          data['role'], data['department'], staff_id, data['img_url'], update_by, update_at, module_name, is_active))
        logger.info(f"Staff {data['first_name']} added to the system.")
    except ConnectTimeoutError:
        logger.error(f"Error occur when inserting company details ")
    except ReadTimeoutError:
        logger.info('Read timeout: server did not respond wihtin timeout period')
    except Exception as e:
        logger.info(f"{e}")
    finally:
        pool.release(conn)


def create_new_invoice(data):
    conn=pool.acquire(timeout=5)
    try:
        cursor = conn.cursor()
        crate_schema_name = cursor.connection.client.schema
        calculated_amount=data['amount']
        total_amount = calculated_amount
        invoice_id = f"""{data['company'][:2]}UUID"""
        sql=f"""INSERT INTO {crate_schema_name}.INVOICES (TO_COMPANY, INVOICE_START_DATE, INVOICE_END_DATE, USAGE_TYPE,
                APPLY_DISCOUNT, DISCOUNT_VALUE, DISCOUNT_TYPE, CALCULATED_AMOUNT, TOTAL_AMOUNT,INVOICE_ID) VALUES (?,?,?,?,?,?,?,?,?,?)"""
        result=cursor.execute(sql, (data['company'],
                                    data['invoice_start_date'],
                                    data['invoice_end_date'],
                                    data['usage_type'],
                                    data['apply_discount'],
                                    data['discount_value'],
                                    data['discount_type'],
                                    calculated_amount,
                                    total_amount,
                                    invoice_id))
        logger.info(f"Invoice generated {invoice_id}")
    except ConnectTimeoutError:
        logger.error(f"Error occur when inserting company details ")
    except ReadTimeoutError:
        logger.info('Read timeout: server did not respond wihtin timeout period')
    except Exception as e:
        logger.error(f"{e}")
        logger.info(f"{e}")
    finally:
        pool.release(conn)

def insert_new_manage_rates(data):
    conn = pool.acquire(timeout=5)

    try:
        voice_billing_rate = data['voice_billing_rate']
        chat_billing_rate = data['chat_billing_rate']

        from datetime import datetime, timezone
        utc = datetime.now(timezone.utc)
        cursor = conn.cursor()
        crate_schema_name = cursor.connection.client.schema
        sql=f"""INSERT INTO {crate_schema_name}.MANAGE_RATES (
            VOICE_BILLING_TYPE,
            VOICE_BILLING_RATE,
            CHAT_BILLING_TYPE,
            CHAT_BILLING_RATE,
            INSERT_AT, 
            UPDATE_AT, 
            INSERT_BY, 
            UPDATE_BY) VALUES (?,?,?,?,?,?,?,?)"""
        result=cursor.execute(sql, (data['voice_billing_type'], voice_billing_rate,
                                    data['chat_billing_type'], chat_billing_rate, utc, None, data['user_id'], None))
        logging.info(f"Inserted Rates by {data['user_id']}")
    except ConnectTimeoutError:
        logger.error(f"Error occur when inserting company details ")
    except ReadTimeoutError:
        logger.info('Read timeout: server did not respond wihtin timeout period')
    except Exception as e:
        logger.info(f"{e}")
    finally:
        pool.release(conn)


def get_all_active_roles_and_departments():
    conn = pool.acquire(timeout=5)
    all_role = set()
    try:
        cursor = conn.cursor()
        crate_schema_name = cursor.connection.client.schema
        sql=f"""SELECT DISTINCT rolepermission FROM {crate_schema_name}.ROLES WHERE isactive=True"""
        cursor.execute(sql)
        all_active_roles=cursor.fetchall()
        for r in all_active_roles:
           all_role.update(set(r[0].split("|")))
        all_role_tuple = tuple(all_role)
        #placeholders = ", ".join(["(%s)"] * len(all_role))
        placeholders = ", ".join(["?"] * len(all_role))
        sql=f"""select staff_role, count(*) as number_of_staff from {crate_schema_name}.staff_details where staff_role in ({placeholders}) group by staff_role"""
        cursor.execute(sql, (all_role_tuple))
        res = cursor.fetchall()
        all_roles_and_people = dict(map(tuple, res))
        for r in all_role_tuple:
            if r not in all_roles_and_people:
                all_roles_and_people.update({r:0})

        sql = f"""SELECT DISTINCT departmentname FROM {crate_schema_name}.departments WHERE isactive=True"""
        cursor.execute(sql)
        all_active_departments = cursor.fetchall()
        placeholders = ", ".join(["?"] * len(all_active_departments))
        all_departments_tuple = tuple(item[0] for item in all_active_departments)
        sql = f"""select staff_departmant, count(*) as number_of_staff from {crate_schema_name}.staff_details where staff_departmant in ({placeholders}) group by staff_departmant"""
        cursor.execute(sql, (all_departments_tuple))
        res = cursor.fetchall()
        all_departments_and_people = dict(map(tuple, res))
        for r in all_departments_tuple:
            if r not in all_departments_and_people:
                all_departments_and_people.update({r: 0})
        logger.info("Successfully received number of people under each role and department.")
    except ConnectTimeoutError:
        logger.error(f"Error occur when inserting company details ")
    except ReadTimeoutError:
        logger.info('Read timeout: server did not respond wihtin timeout period')
    except Exception as e:
        logger.info(f"{e}")
    finally:
        conn.commit()
        pool.release(conn)
    return all_roles_and_people,all_departments_and_people

def add_new_role_and_department(data):
    conn = pool.acquire(timeout=5)
    try:
        from datetime import datetime, timezone
        utc = datetime.now(timezone.utc)
        cursor = conn.cursor()
        crate_schema_name = cursor.connection.client.schema
        user=data['user']
        if data['roles'] is not None:
            role_name=data['roles']['name']
            role_permission=data['roles']['permission']
            role_permission_str = "|".join(map(str, role_permission))

            sql_update=f"""UPDATE {crate_schema_name}.ROLES SET ISACTIVE=? AND UPDATEBY=? AND UPDATEAT=? WHERE ROLENAME=?"""
            cursor.execute(sql_update, (False, user, utc, role_name))

            sql=f"""INSERT INTO {crate_schema_name}.ROLES (ROLENAME, ROLEPERMISSION, UPDATEBY, UPDATEAT, ISACTIVE) VALUES (?,?,?,?,?)"""
            cursor.execute(sql, (role_name,role_permission_str, user, utc, True))
            logger.info("Roles Added ")

        if data['departments'] is not None:
            department_name=data['departments']['name']
            sql_update=f"""UPDATE {crate_schema_name}.DEPARTMENTS SET ISACTIVE=? AND UPDATEBY=? AND UPDATEAT=? WHERE DEPARTMENTNAME=?"""
            cursor.execute(sql_update, (False, user, utc, department_name))
            sql=f"""INSERT INTO {crate_schema_name}.DEPARTMENTS (DEPARTMENTNAME,ISACTIVE,UPDATEBY,UPDATEAT ) VALUES (?,?,?,?)"""
            cursor.execute(sql, (department_name, True, user, utc))
            logger.info(f"Department Added.")
    except ConnectTimeoutError:
         logger.error(f"Error occur when inserting company details ")
    except ReadTimeoutError:
        logger.info('Read timeout: server did not respond wihtin timeout period')
    except Exception as e:
        logger.info(f"{e}")
    finally:
        conn.commit()
        pool.release(conn)


def insert_new_announcement(data):
    conn = pool.acquire(timeout=5)
    try:
        from datetime import datetime, timezone
        utc=datetime.now(timezone.utc)
        cursor = conn.cursor()
        crate_schema_name = cursor.connection.client.schema
        # Selective Tracxion Department='S'
        # All Companues='A'
        # Selective Companies='C'
        # All Tracxion Staffs='T'
        # Selective Traxcion Staffs='D'
        announce_type=data['category']['key']
        #value=data['category']['values']
        values="|".join(map(str, data['category']['values']))
        sql=f"""INSERT INTO {crate_schema_name}.NEW_ANNOUNCEMENT (ANNOUNCEMENT_NAME, ANNOUNCEMENT_TYPE, ANOUNCEMENT_CATEGORY,ANNOUNCE_LIST, ANNOUNCEMENT_DESCRIPTION, CREATED_DATE,CREATED_BY) 
        VALUES (?,?,?,?,?,?,?)"""
        result=cursor.execute(sql, (data['name'], data['type'],announce_type,values, data['desc'],utc, data['created_by']))
    except ConnectTimeoutError:
        logger.error(f"Error occur when inserting company details ")
    except ReadTimeoutError:
        logger.info('Read timeout: server did not respond wihtin timeout period')
    except Exception as e:
        logger.info(f"{e}")
    finally:
        pool.release(conn)

def insert_new_company_details(data):
    conn=pool.acquire(timeout=5)
    try:
        cursor=conn.cursor()
        crate_schema_name=cursor.connection.client.schema
        from datetime import datetime, timezone
        utc = datetime.now(timezone.utc)
        sql_update_company=f"""SELECT count(*) from {crate_schema_name}.COMPANY_DETAILS"""
        cursor.execute(sql_update_company)
        res = cursor.fetchall()[0]
        company_id = data['company_name'][:3]+str(utc.month)+str(utc.year)+str(utc.day)+str(res[0]+1)

        sql = f"""INSERT INTO {crate_schema_name}.COMPANY_DETAILS (COMPANY_NAME, COMPANY_OWNER_FIRST_NAME, COMPANY_OWNER_LAST_NAME, COMPANY_EMAIL,
               COMPANY_CONTACT_NUMBER, COMPANY_ADDRESS, COMPANY_CITY_NM, COMPANY_ST_NM, COMPANY_ZP_CD, COMPANY_LOGO_URL, IS_ACTIVE, UPDATE_BY, UPDATE_AT, MODULE, COMPANY_ID) 
               VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"""
        result = cursor.execute(sql, (data['company_name'], data['company_owner_first_name'], data['company_owner_last_name'],
                                      data['company_email'],data['company_contact_number'],data['company_address'],
                                      data['company_city_nm'], data['company_st_nm'], data['company_zp_cd'], data['company_logo_url'], True, data['user'], utc, data['module'], company_id))
        logger.info(f"Company {data['company_name']}  and company id {company_id} is added to the system successfully")
    except ConnectTimeoutError:
        logger.error(f"Error occur when inserting company details ")
    except ReadTimeoutError:
        logger.info('Read timeout: server did not respond wihtin timeout period')
    except Exception as e:
        logger.info(f"{e}")
    finally:
        pool.release(conn)

def get_live_agent(message_id):
    conn = pool.acquire(timeout=5)
    try:
        cursor = conn.cursor()
        crate_schema_name = cursor.connection.client.schema
        sql=f"""SELECT user_id, connection_id FROM {crate_schema_name}.ws_connections WHERE messageid=? order by connected_at DESC limit 1"""
        cursor.execute(sql, (message_id,))
        res=cursor.fetchall()
        # if len(res)==0:
        #     logger.info(f"First time user.")
        #     sql = f"""SELECT user_id, connection_id FROM {crate_schema_name}.ws_connections WHERE customer_contact_number=? order by connected_at DESC limit 1"""
        #     cursor.execute(sql, (contact_customer_number,))
        #     res = cursor.fetchall()
        if len(res)>0:
            logger.info(f"Available Agent ID {res[0][0]} and respective connection id {res[0][1]}")
            return res[0][0], res[0][1] #agent_id, connection_id
        else:
            return '',''
    except Exception as e:
        logger.error(f"Error occurred when fetching live agent {e}")
    return None,None

def _get_all_is_active_connection(redis_conn, is_active):
    index_key = "active_connections" if is_active == 1 else "inactive_connections"

    connection_ids = list(redis_conn.smembers(index_key))
    if not connection_ids:
        return []

    pipe = redis_conn.pipeline()
    for cid in connection_ids:
        pipe.hgetall(cid)

    records = pipe.execute()

    result = []
    for cid, data in zip(connection_ids, records):
        if data:  # safety check
            result.append({
                "connection_id": cid,
                "agent_id": data.get("agent_id"),
                "message_id": data.get("message_id"),
                "is_active": int(data.get("is_active", 0))
            })

    return result

def _get_is_active_connection(redis_conn, is_active):
    index_key = "active_connections" if is_active == 1 else "inactive_connections"

    connection_ids = list(redis_conn.smembers(index_key))
    if not connection_ids:
        return []
    else:
        return [connection_ids[0]]


def get_agent_connection_id_for_customer(customer_contact_number, messageId):
    logger.info(f"Customer IC {customer_contact_number} and messageId {messageId} is using to search an available agent")
    conn = pool.acquire(timeout=15)
    try:
        cursor = conn.cursor()
        crate_schema_name = cursor.connection.client.schema
        status=False
        logger.info(f"Selecting agent who are available or free and ready to accept new customer.")
        # sql_select_agent=f"""SELECT user_id, connection_id, count(*) from {crate_schema_name}.ws_connections group by user_id, connection_id """
        sql_select_active_agent = f"""SELECT user_id, connection_id, real_time_connection_id, messageid FROM {crate_schema_name}.ws_connections WHERE  
                            customer_contact_number=? LIMIT 1"""
        cursor.execute(sql_select_active_agent, (customer_contact_number,))
        results = cursor.fetchall()
        if len(results) > 0:
            result = results[0]
            agent_id = result[0]
            connection_id = result[1]
            real_time_connection_id = result[2]
            message_id = result[3]
            logger.info(f"Agent {agent_id} is returning with connection {connection_id} with real-connection string {real_time_connection_id} message_id {message_id}")

            if message_id!=messageId:
                logger.info(f"Agent Id {agent_id} have message id {messageId} is updating to {message_id}")
                sql_connect_agent = f"""UPDATE {crate_schema_name}.ws_connections SET messageid=? 
                                                    WHERE user_id=? AND connection_id=? AND customer_contact_number=? AND real_time_connection_id=?"""
                cursor.execute(sql_connect_agent,
                               (messageId, agent_id, connection_id, customer_contact_number, real_time_connection_id,))
            return agent_id, connection_id, real_time_connection_id,message_id
        else:
            sql = f"""
                        SELECT agent_id, agent_name, count_connected_customer FROM {crate_schema_name}.realtime_agents_presence WHERE status=True limit 1
                    """
            cursor.execute(sql)
            res = cursor.fetchall()
            if len(res) > 0:
                agent_id = res[0][0]
                agent_name = res[0][1]
                count_connected_customer = res[0][2]
                logger.info(f"Creating new connection for Agent ID {agent_id} agent name {agent_name} phone {count_connected_customer} from wpadminmod ")
                sql_select_connection_id = f"""SELECT connection_id, real_time_connection_id FROM {crate_schema_name}.ws_connections WHERE user_id=? AND messageid='demo' AND customer_contact_number=? LIMIT 1"""
                cursor.execute(sql_select_connection_id, (agent_id,customer_contact_number,))
                res = cursor.fetchone()
                if res is None:
                    logger.info(f"No Agent available")
                    return None, None, None, None # no agent found
                connection_id = res[0]
                real_time_connection_id = res[1]
                logger.info(f"Agent {agent_id} with name {agent_name} is used as connection_id {connection_id} and real_connection_id {real_time_connection_id}")
                from datetime import datetime, timezone
                utc = datetime.now(timezone.utc)
                # We update later########PRAKASH###########
                if count_connected_customer>50: #One agent can only handle 5 customers at any moment
                    sql = f"""UPDATE {crate_schema_name}.realtime_agents_presence set status=?, updated_at=? WHERE agent_id=?"""
                    cursor.execute(sql, (status, utc, agent_id,))
                logger.info(f"Agent Id {agent_id} become busy with customer {customer_contact_number} and start receiving messages.")
                sql_connect_agent = f"""UPDATE {crate_schema_name}.ws_connections SET messageid=? 
                                    WHERE user_id=? AND connection_id=? AND customer_contact_number=? AND real_time_connection_id=?"""
                cursor.execute(sql_connect_agent, (messageId, agent_id, connection_id,customer_contact_number, real_time_connection_id,))
                redis_conn=redis_pool_obj.acquire(timeout=10)
                client_objects = redis_conn.hgetall(customer_contact_number)
                client_objects.update({
                    "message_id": messageId,
                    "connection": connection_id,
                    "real_time_connection_id" : real_time_connection_id,
                    "is_active": 0  # 0->False->Occupied by a customer, 1->True->Available to Serve
                })
                redis_conn.hset(customer_contact_number, mapping=client_objects)
                redis_conn.sadd("inactive_connections", customer_contact_number)
                redis_conn.srem("active_connections", customer_contact_number)

                return agent_id, connection_id, real_time_connection_id, messageId
            else:
                raise Exception(f"No active agent available")

    except Exception as e:
        logger.error(f"Error in getting any available agent {e}")
        return None, None, None, None

def run_query():
    conn = pool.acquire(timeout=5)
    try:
        cursor = conn.cursor()
        crate_schema_name = cursor.connection.client.schema
        sql = f"""INSERT INTO {crate_schema_name}.locations 
                    (name, date, kind, pos) VALUES ( ?,?,?,?)"""
        result = cursor.execute(sql, ('raju1','2015-01-02', 'space', 100))
        return result
    except ConnectTimeoutError:
        logger.info('Connection timeout: Could not establish connection within timeout period')
    except ReadTimeoutError:
        logger.info('Read timeout: server did not respond wihtin timeout period')
    except Exception as e:
        logger.info(f"{e}")
    finally:
        pool.release(conn)

#run_query()
logger.info("Started wpadminmod lambda successfully")
#pool.close_all()

