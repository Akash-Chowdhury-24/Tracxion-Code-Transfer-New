import threading
from typing import Any


class ThreadSafeDict:
    def __init__(self):
        self._dict = {}
        self._lock = threading.Lock()

    def __getitem__(self, key: Any) -> Any:
        with self._lock:
            return self._dict[key]

    def __setitem__(self, key: Any, value: Any) -> None:
        with self._lock:
            self._dict[key] = value

    def __delitem__(self, key: Any) -> None:
        with self._lock:
            del self._dict[key]

    def get(self, key: Any, default: Any = None) -> Any:
        with self._lock:
            return self._dict.get(key, default)

    def pop(self, key: Any, default: Any = None) -> Any:
        with self._lock:
            return self._dict.pop(key, default)

    def keys(self):
        with self._lock:
            return list(self._dict.keys())

    def values(self):
        with self._lock:
            return list(self._dict.values())

    def items(self):
        with self._lock:
            return list(self._dict.items())

    def __len__(self) -> int:
        with self._lock:
            return len(self._dict)
