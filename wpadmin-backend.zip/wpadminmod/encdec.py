
import string
# def encrypt(text, key):
#     res = []
#     for i, c in enumerate(text):
#         # Deterministic shift using key
#         res.append(chr(ord(c) + ord(key[i+200 % len(key)])))
#     return "".join(res)
#
# def decrypt(encrypted_text, key):
#     res = []
#     for i, c in enumerate(encrypted_text):
#         # Reverse shift using key
#         res.append(chr(ord(c) - ord(key[i+200 % len(key)])))
#     return "".join(res)

def encrypt(text, key):
    # Define character groups
    lower = string.ascii_lowercase
    upper = string.ascii_uppercase
    digits = string.digits
    specials = string.punctuation
    all_symbols = lower + upper + digits + specials

    key_sum = sum(ord(c) for c in key)  # derive a numeric key for shifting

    encrypted = ''
    for c in text:
        if c in all_symbols:
            idx = all_symbols.index(c)
            # Deterministic (but not secure) shift
            e_idx = (idx + key_sum) % len(all_symbols)
            encrypted += all_symbols[e_idx]
        else:
            encrypted += c  # leave other chars unchanged
    return encrypted

def decrypt(text, key):
    lower = string.ascii_lowercase
    upper = string.ascii_uppercase
    digits = string.digits
    specials = string.punctuation
    all_symbols = lower + upper + digits + specials

    key_sum = sum(ord(c) for c in key)

    decrypted = ''
    for c in text:
        if c in all_symbols:
            idx = all_symbols.index(c)
            d_idx = (idx - key_sum) % len(all_symbols)
            decrypted += all_symbols[d_idx]
        else:
            decrypted += c
    return decrypted

# Usage
text = "SuperSecrectPass"
key = "dKX9nVr3BpmuAq7QZ1e4chfN8yUFw6EoRjtILzvGHxTWJMC58bB0Y2kDsOqaglPSRHwLomCT7FEK9n8rdjAYG1VhZiz3Xfp5QeWs4uyUKwVlo8SJF7NHX29zcbtRhQ6MpreTGi5AndskPLBXxo1v3a4QyZEpJU9w6g7SF2RCzMlTVYHtqficNKjXm0WnDrBO1hkXyZ4uQToeIGLEavPp2HtAsXU9rg3fBlWxD1nC6cJq75zMAyb0kiYFOspHSVN2BWQ84rxGTFUeMRkcLJ7Zd1as2IqyoVvh83nbOPwAXpSgK9Lt5"
encrypted = encrypt(text, key)
decrypted = decrypt(encrypted, key)

print("Encrypted:", encrypted)
print("Decrypted:", decrypted)
