import requests
from chalice import Chalice, BadRequestError, CORSConfig, Response, Rate, Cron
from langdetect import detect
#import langid
#from fasttext_langdetect import detect
import boto3
import os
import re
import io

#from requests_toolbelt.multipart import decoder
import chalicelib.cratedb_operation as db_opr_service
from werkzeug.formparser import parse_form_data
from typing import Dict, Any
import json
import threading
import logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

#from ThreadSafeChatClass import ThreadSafeDict

app = Chalice(app_name='wpadminmod')
s3 = boto3.client('s3')
sqs = boto3.client('sqs')
bucket_name=os.environ.get('BUCKET_NAME', 'adminbucketadminmod')
sqs_url=os.environ.get('SQS_QUERY_URL', 'https://sqs.ap-south-1.amazonaws.com/839393571674/wpadmintraxsionsqsservice')
key=os.environ.get('KEY', 'DemoKey')
comprehend = boto3.client(service_name='comprehend', region_name='ap-south-1')
open_ai_service_url="https://gedajcbms5.execute-api.ap-south-1.amazonaws.com/api/getquestions"

GREETINGS = {
    "hi", "hello", "hey", "hai",
    "how are you", "how r you",
    "good morning", "good afternoon", "good evening",
    "whats up", "what's up",
    "sup",
    "bye",
    "Thank you", "Thanks",
    "sure",
    "ok","right",
    "yes","no",
    "may be"
}

cors_config = CORSConfig(
    allow_origin='*',
    allow_headers=['X-Special-Header', 'Content-Type', 'Authorization'],
    max_age=600,
    expose_headers=['X-Special-Header'],
    allow_credentials=True
)

def _should_run_sentiment(text_string, language_code):
    logger.info("Sentiment analysis will be performed only on long text. ")

    def _remove_special_chars(text_string):
        return re.sub(r'[^a-zA-Z0-9\s]', '', text_string)

    def _is_greeting(text_string: str, language_code: str) -> bool:
        text_string = text_string.lower().strip()
        text_string = re.sub(r"[^\w\s]", "", _remove_special_chars(text_string))  # remove punctuation
        # exact or contained match
        if len(text_string)>3:
            return False
        return any(greet == text_string or greet in text_string for greet in GREETINGS)

    def _is_too_short(text_string: str, min_words=3) -> bool:
        return len(text_string.split()) < min_words

    if not text_string or not text_string.strip():
        return False

    if _is_greeting(text_string,language_code):
        return False

    if _is_too_short(text_string):
        return False

    return True


def _filename_from_disposition(value:str | None) ->str | None:
    if not value:
        return None
    m = re.search(r'filename="([^"]+)"', value)
    return m.group(1) if m else None

def _analyze_user_text(text_string, language_code):
    if not _should_run_sentiment(text_string, language_code):
        logger.info(f"{text_string} of {language_code} is not allowed for sentiment analysis. Proceeding without calling Comprehend.")
        return False
    return True
#
# @app.schedule(Rate(1, unit=Rate.MINUTES))
# def scheduled_task(event):
#     logger.info("Scheduled task executed every minute")

# @app.schedule(Cron(0/1, '*', '*', '*', '?', '*'))
# def scheduled_task(event):
#     logger.info("Runs every minute")
def _worker_detect_sentiment(comprehend, text_string, language_code, output):
    # Detect sentiment
    print(f"Detect sentiment {language_code}")
    sentiment_response = comprehend.detect_sentiment(
        Text=text_string,
        LanguageCode=f"{language_code}"  # Change if needed
    )
    output['sentiment_response'] = sentiment_response

def _worker_detect_entities(comprehend, text_string, language_code, output):
    # Detect entities
    print(f"Detect entities {language_code}")
    entities_response = comprehend.detect_entities(
        Text=text_string,
        LanguageCode=f"{language_code}"  # Change if needed
    )
    output['entities_response'] = entities_response

def _worker_detect_dominant_language(comprehend, text_string, output):
    # Detect dominant language
    dominant_language = comprehend.detect_entities(
        Text=text_string
    )
    output['dominant_language'] = dominant_language

def _worker_detect_pii_entities(comprehend, text_string, language_code, output):
    # Detect pii data
    print(f"Detect pii {language_code}")
    detect_pii_entities = comprehend.detect_pii_entities(
        Text=text_string,
        LanguageCode=f"{language_code}"
    )
    output['detect_pii_entities'] = detect_pii_entities

def _worker_sqs_send_message(response):
    # Prepare message for SQS
    sqs_response = sqs.send_message(
        QueueUrl=sqs_url,
        MessageBody=json.dumps(response,)
    )
    # optional: log the MessageId
    logger.info(f"Published to SQS with MessageId successfully: {sqs_response['MessageId']}")

def _workder_get_suggestions_from_openai(text_string,questions):
    session = requests.Session()
    try:
        logger.info(f"Generating Questions based on your query.")
        headers = {
            'Content-Type': 'application/json'
        }
        payload = json.dumps({
            "message": text_string
        })
        response_questions = session.post(open_ai_service_url, headers=headers, data=payload, timeout=20)
        # response = requests.request("POST", url, headers=headers, data=payload)
        questions = json.loads(json.loads(response_questions.text)['body'])['message']
        logger.info(f"Suggestions questions gathers for {text_string}")
    except Exception as e:
        logger.error(f"Error occured when calling openai service {e}")
    finally:
        session.close()

@app.route('/')
def index():
    return {'ping': 'pong'}

@app.route('/getagent', methods=['POST'], content_types=['application/json'], cors=cors_config)
def get_agent_id_and_assign():
    logger.info(f"Getting an available Agent from available agent database")
    try:
        request = app.current_request
        data = request.json_body  # Parse JSON payload
        logger.info(f"Searching Agent {data}")
        agent_id, connection_id, real_time_connection_id, message_id = db_opr_service.get_agent_connection_id_for_customer(
            customer_contact_number=data['customer_contact_number'], messageId=data['message_id'])
        if agent_id is None or connection_id is None or real_time_connection_id is None:
            raise Exception(f"No Agent found")
        if agent_id is not None:
            return {"agent_id": agent_id,
                    'connection_id':connection_id,
                    'message_id': message_id,
                    "real_time_connection_id": real_time_connection_id,
                    'statusCode': 200}
        else:
            return {'agent_id': '',
                    'connection_id':'',
                    'message_id': '',
                    'real_time_connection_id':'', 'statusCode': 400}
    except Exception as e:
        logger.error(f"Error occurred when searching agent:  {e}")
        return {
            "statusCode": 400,
            "body": {"message": "Agent Not found"}
        }

@app.route('/sentiment', methods=['POST'], content_types=['application/json'], cors=cors_config)
def get_sentiment_analysis_result():
    text = f"""This is a dangerous condition for India and US based on Donald Trump's mad dicisoon on putting pressure on India. 
            Putin is very aggresive on this situation."""
    request = app.current_request
    data = request.json_body  # Parse JSON payload
    logger.info(f"User data {data}")
    allowed_languages=['hi', 'de', 'zh-TW', 'ko', 'pt', 'en', 'it', 'fr', 'zh', 'es', 'ar', 'ja']
    try:
        user_name = data['name']
        agent_id=data['agent_id']
        empresa_id=data['empresa_id']
        text_string = data['text']

        message_id=data['messageId']
        id=data['id']
        customer_contact_number = data['customer_contact_number']
        language_code = detect(text_string)

        #language_code, confidence = langid.classify(text)
        logger.info(f"User {user_name} is using the text {text_string} for sentiment Analysis language code {language_code}")
        if language_code not in allowed_languages:
            logger.info(f"{language_code} is not allowed. Selecting default language for sentiment analysis.")
            language_code='en' #Default language

        if not _analyze_user_text(text_string=text_string, language_code=language_code):
            response = {
                'sentiment': "NORMAL",
                'sentiment_score': 0.00,
                'entities': [],
                'user_text': text_string,
                'messageId': message_id,
                "id": id,
                "customer_contact_number": customer_contact_number,
                "agent_id": agent_id,
                "empresa_id": empresa_id,
                "sentiment_summary": {
                            "Positive": 0.0,
                            "Negative": 0.0,
                            "Neutral": 0.0,
                            "Mixed": 0.0
                            }
                }
            return {
                'statusCode': 200,
                'body': json.dumps(response),
                'sentiment': "NORMAL",
                'language': language_code,
                "suggestion": [f"Welcome {user_name}, Please help to explain your questions in detail.","",""]
            }
        else:
            logger.info(f"{text_string} is allowed for sentiment analysys of language code {language_code}")
            output = {}

            # Create threads for each operation
            threads = [
                threading.Thread(target=_worker_detect_sentiment, args=(comprehend, text_string, language_code, output)),
                threading.Thread(target=_worker_detect_entities, args=(comprehend, text_string, language_code, output)),
                #threading.Thread(target=_worker_detect_dominant_language, args=(comprehend, text_string, output)),
                #threading.Thread(target=_worker_detect_pii_entities, args=(comprehend, text_string, language_code, output))
            ]


            # t = threading.Thread(target=_worker_detect_sentiment, args=(task, results))
            # threads.append(t)
            # t.start()

            # Detect sentiment
            # sentiment_response = comprehend.detect_sentiment(
            #     Text=text_string,
            #     LanguageCode=f"{language_code}"  # Change if needed
            # )

            # Detect entities
            # entities_response = comprehend.detect_entities(
            #     Text=text_string,
            #     LanguageCode=f"{language_code}"
            # )

            # Detect pii data
            # detect_pii_entities = comprehend.detect_pii_entities(
            #     Text=text_string,
            #     LanguageCode=f"{language_code}"
            # )

            # Start all threads
            for t in threads:
                t.start()

            # Wait for all threads to finish
            for t in threads:
                t.join()

            # Detect detect_dominant_language
            dominant_language = comprehend.detect_dominant_language(
                Text=text_string
            )

            # Extract entity names
            #entity_names = [entity['Text'] for entity in entities_response['Entities']]
            entity_names=[]
            for entity in output.get('entities_response')['Entities']:
                entity_names.append(entity['Text'])

            response = {
                'userID': 'admin',
                'sentiment': output.get('sentiment_response')['Sentiment'],
                'sentiment_score': output.get('sentiment_response')['SentimentScore'],
                "dominant_language" : dominant_language['Languages'],
                #"detect_pii_entities": output.get('detect_pii_entities')['Entities'],
                'entities': entity_names,
                'user_text': text_string,
                'messageId' : message_id,
                "id":id,
                "customer_contact_number" : customer_contact_number,
                "agent_id": agent_id,
                "empresa_id" : empresa_id
            }

            # Prepare message for SQS
            sqs_response = sqs.send_message(
                QueueUrl=sqs_url,
                MessageBody=json.dumps(response )
            )
            # optional: log the MessageId
            logger.info(f"Published to SQS with MessageId successfully: {sqs_response['MessageId']}")
            session = requests.Session()
            try:
                logger.info(f"Generating Questions based on your query.")
                headers = {
                    'Content-Type': 'application/json'
                }
                payload = json.dumps({
                    "message": text_string
                })
                response_questions = session.post(open_ai_service_url, headers=headers, data=payload, timeout=10)
                # response = requests.request("POST", url, headers=headers, data=payload)
                questions = json.loads(json.loads(response_questions.text)['body'])['message']
                logger.info(f"Suggestions questions gathers for {text_string}")
            except Exception as e:
                logger.error(f"Error occured when calling openai service {e}")
            finally:
                session.close()

            logger.info(f"Sentiment Analysis is completed. {questions}")
            return {
                'statusCode': 200,
                'body': json.dumps(response),
                'sentiment': response['sentiment'],
                'sentiment_summary': response['sentiment_score'],
                'language': language_code,
                "suggestion": [questions[0], questions[1], questions[2]]
            }
    except Exception as e:
        logger.error(f"Error occurred when performing Sentiment analysis {e}")
        return {
            "status" : 400,
            "body": {"message": "AWS Comprehend is unreachable"}
        }


@app.route('/enter', methods=['POST'], content_types=['application/json'], cors=cors_config)
def login_operation():
    logger.info(f"Login operation started.....")
    request = app.current_request
    data = request.json_body  # Parse JSON payload
    try:
        # Create an Argon2 password hasher
        #ph = PasswordHasher()

        user_name=data['name']
        secret_string=data['pass']
        module_name=data['module']

        # password_bytes = bytes(characters, "utf-8")
        # key = Fernet.generate_key()  # Save this securely!
        # cipher_suite = Fernet(key)
        # encrypted = cipher_suite.encrypt(password_bytes)
        # decrypted = cipher_suite.decrypt(encrypted).decode("utf-8")
        # logger.info(encrypted)
        # logger.info(decrypted)

        if key=='DemoKey':
            logger.info("Error reading environment variable")
            return Response(
                body={"message": f"Error reading environment variable",
                      "details": "",
                      "status": 400},
                status_code=200,
                headers={'Content_Type': 'applicationjson'}
            )
        user_details=db_opr_service.check_login_of_user(user_name, secret_string, module_name, key)
        if len(user_details) ==1:
            return Response(
                    body={"message": f"User matched",
                          "details" : "",
                          "status": 200},
                    status_code=200,
                    headers={'Content_Type': 'applicationjson'}
                )
        else:
            return Response(
                body={"message": f"user not matched",
                      "details": "",
                      "status": 200},
                status_code=200,
                headers={'Content_Type': 'applicationjson'}
            )
    except Exception as e:
        logger.info(f"Error appear when login initiated. {e}")




@app.route('/opronsinglerecord', methods=['POST'], content_types=['application/json'], cors=cors_config)
def edit_view_delete_single_record():
    logger.info("Initiating edit/view/delete operation for single operation")
    request = app.current_request
    data = request.json_body  # Parse JSON payload
    try:
        module_name = data['module_name'] # Company/staff
        record_name = data['record_name'] #Record ID
        operation_type = data['operation_type'] #Edit/View/Delete #E-Edit, V-View, #D-Delete
        user_id = data['user']

        if module_name=='company':
            #Perform operation for Company
            company_details = db_opr_service.perform_corn_for_individual_company(record_name, operation_type, user_id)
            return Response(
                body={"message": f"Company {record_name} details has been fetched ",
                      "details" : company_details,
                      "status": 200},
                status_code=200,
                headers={'Content_Type': 'applicationjson'}
            )
        elif module_name=='staff':
            #Perform operation for staff
            logger.info("staf......")
            #company_details = db_opr_service.perform_corn_for_individual_company(record_name, operation_type, user_id)
            staff_details=db_opr_service.perform_corn_for_individual_staff(record_name, operation_type, user_id)
            return Response(
                body={"message": f"Staff {record_name} details has been fetched ",
                      "details": staff_details,
                      "status": 200},
                status_code=200,
                headers={'Content_Type': 'applicationjson'}
            )
        else:
            # No module name is defined. Operation is not progressing.
            logger.info("no event")
    except Exception as e:
        logger.info("Error processing modification data.")
    return None



@app.route('/getallrolesanddepartments', methods=['GET'], content_types=['application/json'], cors=cors_config)
def get_all_roles_departments():
    request = app.current_request
    qp = request.query_params or {}
    try:
        logger.info("Start getting all active role.")
        all_roles_and_people, all_departments_and_people=db_opr_service.get_all_active_roles_and_departments()
        if all_roles_and_people is None and all_departments_and_people is None:
            return Response(
                body={"message": "Error fetching records from database. Consult to the admin",
                      "status": 400},
                status_code=400,
                headers={'Content_Type': 'applicationjson'}
            )
        return Response (
            body = {"message": "Received department and role wise number of people",
                    "role": all_roles_and_people,
                    "department": all_departments_and_people,
                    "status": 200},
            status_code= 200,
            headers = {'Content_Type': 'applicationjson'}
        )
    except Exception as e:
        logger.info(e)


@app.route('/addroledepartment', methods=['POST'], content_types=['application/json'], cors=cors_config)
def add_new_role_department():
    request = app.current_request
    data = request.json_body  # Parse JSON payload
    if data is None:
        message ="Empty input dataset"
        return Response (
            body = {'message': message, 'status': 400},
            status_code=400,
            headers={'Content_Type': 'applicationjson'}
        )
    db_opr_service.add_new_role_and_department(data)
    message =f"""Role/Department added."""
    logger.info("Role/Department added.")
    return Response(
        body={'message': message, "status": 200},
        status_code=200,
        headers={'Content-Type': 'application/json'}
    )

@app.route('/editworkinghours', methods=['POST'], content_types=['application/json'], cors=cors_config)
def edt_working_hours():
    request = app.current_request
    data = request.json_body  # Parse JSON payload
    weekly_hours = data['schedule']  # Weekly hours
    holiday_list = data['holidays']  # holiday details
    user_id = data['user']

    if user_id is None:
        message = f"User ID is mandatory field."
        return Response(
            body={'message': message, "status": 400},
            status_code=400,
            headers={'Content-Type': 'application/json'}
        )

    if len(weekly_hours)==0 and len(holiday_list)==0:
        message=f"No Weekly details and holiday details are available. Fix the input json"
        return Response(
            body={'message': message, "status": 400},
            status_code=400,
            headers={'Content-Type': 'application/json'}
        )

    # Validation
    db_opr_service.edit_new_working_hours(data)
    user_id = data['user']
    message = f"Hello {user_id} Your POST request worked"
    return Response(
        body={'message': message,"status": 200},
        status_code=200,
        headers={'Content-Type': 'application/json'}
    )


@app.route('/getliveagent', methods=['GET'], content_types=['application/json'], cors=cors_config)
def get_live_agent():
    request=app.current_request
    qp = request.query_params or {}
    try:
        message_id=qp.get('message_id')
        agent_id, connection_id=db_opr_service.get_live_agent(message_id)
        if agent_id is not None:
            return {
                "agent_id": agent_id,
                "connection_id": connection_id
            }
        else:
            raise Exception("No live agent found")
    except Exception as e:
        logger.error(f"Error fetching live agent {e}")
        return {
            "agent_id": "",
            "connection_id": ""
        }


@app.route('/getstaffs', methods=['GET'], content_types=['application/json'], cors=cors_config)
def get_all_staffs():
    request  = app.current_request
    qp = request.query_params or {}

    try:
        page = int(qp.get('page', 1))
        page_size = min(max(int(qp.get('page_size',10)), 1), 100)
    except ValueError:
        message = f"""Page and page_size must be Integer"""
        raise BadRequestError(f"{message}")

    category =qp.get('category')
    offset = (page - 1) * page_size
    where_clause = ""
    params = []
    if category:
        where_clause=f"""WHERE {category} is not Null and is_active=true"""
        params.append(category)
    else:
        where_clause = f"WHERE is_active=True"
    #get_all_companies(page, page_size, offset,where_clause, params, category)
    res = db_opr_service.get_all_staffs(page, page_size, offset,where_clause, params, category)
    logger.info('Response data')
    return res

@app.route('/getcompanies', methods=['GET'], content_types=['application/json'], cors=cors_config)
def get_all_companies():
    request  = app.current_request
    qp = request.query_params or {}

    try:
        page = int(qp.get('page', 1))
        page_size = min(max(int(qp.get('page_size',10)), 1), 100)
    except ValueError:
        message = f"""Page and page_size must be Integer"""
        raise BadRequestError(f"{message}")

    category =qp.get('category')
    offset = (page - 1) * page_size
    where_clause = ""
    params = []
    if category:
        where_clause=f"""WHERE {category} is not Null"""
        params.append(category)
    else:
        where_clause = f"WHERE is_active=True"
    #get_all_companies(page, page_size, offset,where_clause, params, category)
    res = db_opr_service.get_all_companies(page, page_size, offset,where_clause, params, category)
    logger.info('Response data')
    return res


@app.route('/managerates', methods=['POST'], content_types=['application/json'], cors=cors_config)
def update_manage_rates():
    request = app.current_request
    data = request.json_body  # Parse JSON payload
    # Validation
    if not data or 'voice_billing_type' not in data:
        return Response(
            body={'error': 'Voice Billing Type is not present.'},
            status_code=400,
            headers={'Content-Type': 'application/json'}
        )
    db_opr_service.insert_new_manage_rates(data)
    manage_rates = data['user_id']
    message = f"Hello {manage_rates} Your POST request worked"

    return Response(
        body={'message': message, "status": 200},
        status_code=200,
        headers={'Content-Type': 'application/json'}
    )

@app.route('/newassignment', methods=['POST'], content_types=['application/json'], cors=cors_config)
def upload_new_announcement():
    request = app.current_request
    data = request.json_body  # Parse JSON payload
    # Validation
    if not data or 'desc' not in data:
        return Response(
            body={'error': 'Missing company name field', "status": 400},
            status_code=400,
            headers={'Content-Type': 'application/json'}
        )
    db_opr_service.insert_new_announcement(data)
    announcement_name = data['name']
    message = f"Hello {announcement_name} Your POST request worked"

    return Response(
        body={'message': message, "status": 200},
        status_code=200,
        headers={'Content-Type': 'application/json'}
    )

@app.route('/uploadstaffold', methods=['POST'], content_types=['application/json'], cors=cors_config)
def upload_staff_details():
    request = app.current_request
    data = request.json_body  # Parse JSON payload
    body = request.raw_body
    logger.info("test.....................")

    # Validation
    if not data or 'first_name' not in data:
        return Response(
            body={'error': 'Missing company name field'},
            status_code=400,
            headers={'Content-Type': 'application/json'}
        )
    db_opr_service.insert_new_staff_details(data)
    staff_name = data['first_name']
    message = f"Hello {staff_name} Your POST request worked"

    return Response(
        body={'message': message, "status": 200},
        status_code=200,
        headers={'Content-Type': 'application/json'}
    )

@app.route('/uploadstaff', methods=['POST'], content_types=['multipart/form-data'], cors=cors_config)
def upload_staff_details():
    request = app.current_request
    # data = request.json_body  # Parse JSON payload
    body = request.raw_body

    # Parse multipart form-data using Werkzeug
    environ = {
        'wsgi.input': io.BytesIO(body),
        'CONTENT_LENGTH': str(len(body)),
        'CONTENT_TYPE': request.headers.get('Content-Type'),
        'REQUEST_METHOD': 'POST'
    }

    _, form, files = parse_form_data(environ)

    # --- Get file ---
    image_file = files.get('file')
    if not image_file:
        logger.info(f"Image file is not set. Proceeding without image upload operation.")
        # return Response(
        #     body={'error': 'No image file found under form field "file"'},
        #     status_code=400
        # )
    else:
        # upload image file s3 bucket.
        # --- Upload file to S3 ---
        s3.put_object(
            Bucket=bucket_name,
            Key=image_file.filename,
            Body=image_file.stream,
            ContentType=image_file.mimetype
        )

    # --- Get JSON data ---
    json_data_raw = form.get('data')
    if not json_data_raw:
        return Response(
            body={'error': 'No JSON data found under form field "data"'},
            status_code=400
        )
    try:
        json_data = json.loads(json_data_raw)
        image_url = f"https://{bucket_name}.s3.amazonaws.com/{image_file.filename}"
        json_data['img_url'] = image_url
        # Validation
        if not json_data or 'first_name' not in json_data:
            return Response(
                body={'error': 'Missing company name field'},
                status_code=400,
                headers={'Content-Type': 'application/json'}
            )

        message = f"Invoice generated for {json_data['first_name']}"

        db_opr_service.insert_new_staff_details(json_data)
        staff_name = json_data['first_name']
        logger.info(f" {staff_name} Staff updated successfully.")
    except Exception as e:
        logger.info(e)
    message = f"Hello {staff_name} Your POST request worked"

    return Response(
        body={'message': message,"status": 200},
        status_code=200,
        headers={'Content-Type': 'application/json'}
    )

#Upload company details
@app.route('/uploadcompanyold', methods=['POST'], content_types=['multipart/form-data'], cors=cors_config)
def upload_company_details():
    request = app.current_request
    data = request.json_body #Parse JSON payload

    #Validation
    if not data or 'company_name' not in data:
        return Response(
            body = {'error': 'Missing company name field'},
            status_code = 400,
            headers={'Content-Type': 'application/json'}
        )

    db_opr_service.insert_new_company_details(data)
    company_name = data['company_name']
    message = f"Hello {company_name} Your POST request worked"

    return Response (
        body={'message': message,"status": 200},
        status_code=200,
        headers={'Content-Type': 'application/json'}
    )

#Upload company details
@app.route('/uploadcompany', methods=['POST'], content_types=['multipart/form-data'], cors=cors_config)
def upload_company_details():
    request = app.current_request
    # data = request.json_body  # Parse JSON payload
    body = request.raw_body

    # Parse multipart form-data using Werkzeug
    environ = {
        'wsgi.input': io.BytesIO(body),
        'CONTENT_LENGTH': str(len(body)),
        'CONTENT_TYPE': request.headers.get('Content-Type'),
        'REQUEST_METHOD': 'POST'
    }

    _, form, files = parse_form_data(environ)

    # --- Get file ---
    image_file = files.get('file')
    if not image_file:
        # return Response(
        #     body={'error': 'No image file found under form field "file"'},
        #     status_code=400
        # )
        logger.info("No image file for Company is set.")
    else:
        # upload image file s3 bucket.
        # --- Upload file to S3 ---
        s3.put_object(
            Bucket=bucket_name,
            Key=image_file.filename,
            Body=image_file.stream,
            ContentType=image_file.mimetype
        )

    # --- Get JSON data ---
    json_data_raw = form.get('data')
    if not json_data_raw:
        return Response(
            body={'error': 'No JSON data found under form field "data"'},
            status_code=400
        )
    try:
        json_data = json.loads(json_data_raw)
        image_url = f"https://{bucket_name}.s3.amazonaws.com/{image_file.filename}"
        json_data['company_logo_url'] = image_url
        # Validation
        if not json_data or 'company_name' not in json_data:
            return Response(
                body={'error': 'Missing company name field'},
                status_code=400,
                headers={'Content-Type': 'application/json'}
            )

        message = f"Invoice generated for {json_data['company_name']}"

        db_opr_service.insert_new_company_details(json_data)
        company_name = json_data['company_name']
    except Exception as e:
        logger.info(f"{e}")
    message = f"""Hello {company_name} Your POST request worked"""
    return Response (
        body={'message': message, "status": 200},
        status_code=200,
        headers={'Content-Type': 'application/json'}
    )



# @app.route('/upload', methods=['POST'],
#            content_types=['multipart/form-data', 'application/octet-stream', 'image/jpeg', 'image/png'],
#            cors=cors_config
#            )
# @app.route('/upload', methods=['POST'],
#            content_types=['multipart/form-data'],
#            cors=cors_config
#            )
# def upload():
#     req = app.current_request
#     content_type =req.headers.get('content-type', '')
#     body =  req.raw_body
#
#     if 'multipart/form-data' in content_type:
#         parts = decoder.MultipartDecoder(body, content_type).parts
#         file_part = next((p for p in parts if b'name="file"' in p.headers.get(b'Content-Disposition', b'')),None)
#         if not file_part:
#             raise BadRequestError('Expected multipart field name "file".')
#
#         disp = file_part.headers.get(b'Content-Disposition', b'').decode()
#         filename= _filename_from_disposition(disp) or 'upload.bin'
#         part_ct=file_part.headers.get(b'Content-Type', b'application/octet-stream').decode()
#
#         s3.put_object(Bucket=bucket_name, Key=filename, Body=file_part.content, ContentType=part_ct)
#         return {'ok':True, 'key': filename}
#
#     filename=(req.query_params or {}).get('filename')
#     if not filename:
#         raise BadRequestError('Provide ?filename= when sending raw body.')
#     s3.put_object(Bucket=bucket_name, Key=filename, Body=body, ContentType=content_type or 'application/octet-stream')
#     return {'ok': True, 'key': filename}



@app.route('/createnewinvoice', methods=['POST'], content_types=['application/json'], cors=cors_config)
def create_invoice():
    request = app.current_request
    data = request.json_body  # Parse JSON payload
    # Validation
    if not data or 'company' not in data:
        return Response(
            body={'error': 'Missing company name field'},
            status_code=400,
            headers={'Content-Type': 'application/json'}
        )
    try:
        response= db_opr_service.create_new_invoice(data)
    except Exception as e:
        logger.info(f"{e}")

    message=f"Invoice generated for {data['company']}"
    return Response(
        body={'message': message,"status": 200},
        status_code=200,
        headers={'Content-Type': 'application/json'}
    )


@app.route('/createnewinvoicedemo', methods=['POST'], content_types=['multipart/form-data'], cors=cors_config)
def create_invoice():
    request = app.current_request
    #data = request.json_body  # Parse JSON payload
    body = request.raw_body

    # Parse multipart form-data using Werkzeug
    environ = {
        'wsgi.input': io.BytesIO(body),
        'CONTENT_LENGTH': str(len(body)),
        'CONTENT_TYPE': request.headers.get('Content-Type'),
        'REQUEST_METHOD': 'POST'
    }

    _, form, files = parse_form_data(environ)

    # --- Get file ---
    image_file = files.get('file')
    if not image_file:
        return Response(
            body={'error': 'No image file found under form field "file"'},
            status_code=400
        )

    # --- Get JSON data ---
    json_data_raw = form.get('data')
    if not json_data_raw:
        return Response(
            body={'error': 'No JSON data found under form field "data"'},
            status_code=400
            )
    try:
        json_data = json.loads(json_data_raw)
        image_url = f"https://{bucket_name}.s3.amazonaws.com/{image_file.filename}"
        json_data['image_url'] = image_url
        # Validation
        if not json_data or 'company' not in json_data:
            return Response(
                body={'error': 'Missing company name field'},
                status_code=400,
                headers={'Content-Type': 'application/json'}
            )

        message = f"Invoice generated for {json_data['company']}"
        #upload image file s3 bucket.
        # --- Upload file to S3 ---
        s3.put_object(
            Bucket=bucket_name,
            Key=image_file.filename,
            Body=image_file.stream,
            ContentType=image_file.mimetype
        )
        # Return S3 URL
        response = db_opr_service.create_new_invoice(json_data)
    except json.JSONDecodeError:
        return Response(
            body={'error': 'Invalid JSON format in field "data"'},
            status_code=400
        )


    return Response(
        body={'message': message, "status": 200},
        status_code=200,
        headers={'Content-Type': 'application/json'}
    )

@app.route('/upload', methods=['POST'], content_types=['multipart/form-data'])
def upload_image_with_json():
    request = app.current_request
    body = request.raw_body

    # Parse multipart form-data using Werkzeug
    environ = {
        'wsgi.input': io.BytesIO(body),
        'CONTENT_LENGTH': str(len(body)),
        'CONTENT_TYPE': request.headers.get('Content-Type'),
        'REQUEST_METHOD': 'POST'
    }

    _, form, files = parse_form_data(environ)

    # --- Get file ---
    image_file = files.get('file')
    if not image_file:
        return Response(
            body={'error': 'No image file found under form field "file"'},
            status_code=400
        )

    # --- Get JSON data ---
    json_data_raw = form.get('metadata')
    if not json_data_raw:
        return Response(
            body={'error': 'No JSON data found under form field "data"'},
            status_code=400
        )

    try:
        json_data = json.loads(json_data_raw)
    except json.JSONDecodeError:
        return Response(
            body={'error': 'Invalid JSON format in field "data"', "status": 200},
            status_code=400
        )

    # --- Upload file to S3 ---
    s3.put_object(
        Bucket=bucket_name,
        Key=image_file.filename,
        Body=image_file.stream,
        ContentType=image_file.mimetype
    )

    # --- Response ---
    return {
        "message": "Upload successful",
        "status": 200,
        "file_name": image_file.filename,
        "metadata": json_data
    }

@app.route("/upload1", methods=["POST"], content_types=["application/octet-stream"], cors=cors_config)
def upload_image():
    """
    Accepts a binary image file and uploads it to S3.
    Example:
        curl -X POST https://<api-id>.execute-api.<region>.amazonaws.com/api/upload \
             --data-binary "@image.jpg" \
             -H "Content-Type: application/octet-stream"
    """
    try:
        # The body contains the raw image bytes
        image_bytes = app.current_request.raw_body

        if not image_bytes:
            return Response(
                body={"error": "No image data received"},
                status_code=400,
                headers={"Content-Type": "application/json"},
            )

        # Create a simple filename (could also use uuid or timestamp)
        file_key = f"upload_{int(app.current_request.context['requestTimeEpoch'])}.jpeg"

        # Upload to S3
        s3.put_object(Bucket=bucket_name, Key=file_key, Body=image_bytes, ContentType="image/jpeg")

        # Return S3 URL
        image_url = f"https://{bucket_name}.s3.amazonaws.com/{file_key}"

        return {"message": "Upload successful", "image_url": image_url}

    except Exception as e:
        return Response(
            body={"error": str(e)},
            status_code=500,
            headers={"Content-Type": "application/json"},
        )
