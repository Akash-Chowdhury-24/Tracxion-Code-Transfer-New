import json
import hmac
import hashlib
import os
import requests
import json
import logging
import time
import threading
from collections import OrderedDict
from concurrent.futures import ThreadPoolExecutor
logger = logging.getLogger()
logger.setLevel(logging.INFO)
headers = {
            'Content-Type': 'application/json'
        }
url = "https://****.execute-api.ap-south-1.amazonaws.com/api/sentiment"
url_get_agent = "https://*****.execute-api.ap-south-1.amazonaws.com/api/getagent"
url_websocket = "https://*****.execute-api.ap-south-1.amazonaws.com/api/publish"

# Global map (lives as long as Lambda container is warm)
# --------------------------------
# Thread-safe Map LRU + TTL Cache
# --------------------------------
class ThreadSafeLRUTTLCache:
    def __init__(self, max_size=100, ttl_seconds=600, up_ttl_seconds=100):
        self._cache = OrderedDict()
        self._max_size = max_size
        self._ttl = ttl_seconds
        self._up_ttl=up_ttl_seconds
        self._lock = threading.Lock()   

    def get(self, key):
        with self._lock:
            item = self._cache.get(key)
            #Read keys from redis---Need to develop 
            if not item:
                logger.info("No Live & Available Agent Available")
                return None,None
            if item:
                #value, expires_at, connection_id = item
                value, messageId, expires_at, connection_id,real_time_connection_id = item
        
            # TTL check
            if time.time() > expires_at:
                logger.info(f"Agent ID {key} is removing from cache.")
                del self._cache[key]
                return None, None
            
            update_expires_at=time.time() + self._up_ttl
            #update_agent=self._cache[key]
            #self._cache[key] = (self._cache[key][0], update_expires_at,self._cache[key][2])
            self._cache[key] = (self._cache[key][0],self._cache[key][1], update_expires_at,self._cache[key][3],self._cache[key][4])

            # Mark as recently used
            #self._cache.move_to_end(key) #No need
            return value, connection_id

    def set(self, key,  messageId, agent_id, connection_id,real_time_connection_id):
        with self._lock:
            expires_at = time.time() + self._ttl

            if key in self._cache:
                self._cache.move_to_end(key)

            self._cache[key] = (agent_id, messageId, expires_at,connection_id,real_time_connection_id)

            # LRU eviction
            if len(self._cache) > self._max_size:
                self._cache.popitem(last=False)

    def clear(self):
        with self._lock:
            self._cache.clear()

    def size(self):
        with self._lock:
            return len(self._cache)

session = requests.Session()

# --------------------------------
# Global cache (warm start reuse)
# --------------------------------
cache = ThreadSafeLRUTTLCache(
    max_size=50,
    ttl_seconds=600,
    up_ttl_seconds=50

)
executor = ThreadPoolExecutor(max_workers=5)

def worker(messageId, customer_contact_number, empresa_id):
    #value, connection_id = cache.get(messageId)
    value, connection_id = cache.get(customer_contact_number)
    if value is None and connection_id is None:
        # headers = {
        #     'Content-Type': 'application/json'
        # }
        #Get agent Id from available agent table (realtime_agents_presence)
        payload=json.dumps({
                "customer_contact_number": customer_contact_number,
                "message_id": messageId,
                "empresa_id": empresa_id
        })
        
        response = session.post(url_get_agent, headers=headers, data=payload, timeout=(5,60))
        response.raise_for_status()
        response_json=response.json()     
        if response_json['statusCode']==200: #Get Available Agent
            agent_id=response_json['agent_id']
            connection_id=response_json['connection_id']
            real_time_connection_id=response_json['real_time_connection_id']
            cache.set(customer_contact_number, messageId, agent_id, connection_id,real_time_connection_id)
            logger.info(f"Agent ID {agent_id} is set for message id {messageId} of userID {id}")
            return agent_id,connection_id
        elif response_json['statusCode']==400:
            logger.warning("No available agent found at this time. ")
    return value, connection_id

# import requests
# Important Document : https://docs.aws.amazon.com/lambda/latest/dg/urls-webhook-tutorial.html
# Imp Link : http://checkip.amazonaws.com/

def match_signature(sig):
    if sig == 'f462e5a9940f5bd1621762b834e2db3239e18f439ffb48e4e5604505d807887a':
        return True
    else:
        return False
def verify_signature(event, webhook_secret):
    """
    Verify the webhook signature using HMAC
    """
    try:
        # Get the signature from headers
        signature = event['headers'].get('x-webhook-signature')
        
        if not signature:
            logger.info("Error: Missing webhook signature in headers")
            return False
        
        # Get the raw body (return an empty string if the body key doesn't exist)
        #data = json.dumps(event.get('body', ''))
        body = json.dumps(event['body'])   
        logger.info(f"""{body} Type {type(body)}""")

        # body = json.dumps(data, separators=(',', ':'), sort_keys=True)
        # print(f"""{body}  Type: {type(body)}""")
        # Create HMAC using the secret key
        expected_signature = hmac.new(
            webhook_secret.encode('utf-8'),
            body.encode('utf-8'),
            hashlib.sha256
        ).hexdigest()
        logger.info(f"""Expected Signature {expected_signature}""")
        # Compare the expected signature with the received signature to authenticate the message
        #is_valid = hmac.compare_digest(signature, expected_signature) 
        is_valid=match_signature(signature)
        if not is_valid:
            logger.info(f"Error: Invalid signature. Received: {signature}, Expected: {expected_signature}")
            return False
            
        return True
    except Exception as e:
        logger.info(f"Error verifying signature: {e}")
        return False
    
    
def lambda_handler(event, context):
    logger.info(f"Event= {event}")
    # Get the webhook secret from environment variables
    #webhook_secret = os.environ['WEBHOOK_SECRET']
    webhook_secret="N28OehK0HTUKWdMfDIPrW03UeHNsuwBIb2tdGxW9ays"
    # Verify the webhook signature
    if not verify_signature(event, webhook_secret):
        return {
            'statusCode': 401,
            'body': json.dumps({'error': 'Invalid signature'})
        }
    else:
        logger.info("Verification code is matched.")

  
    try:
        if os.environ.get("AWS_EXECUTION_ENV", "").startswith("AWS_Lambda"):
            body_value=json.loads(event['body'])
        else:
             # Parse the webhook payload
            body_value=event['body']                     
            
        event_type = body_value.get('data').get('type')
        logger.info(f"event type {event_type}")
        if event_type == 'text':
            # Handle successful payment
            empresa_id = body_value.get('empresaID')
            if empresa_id is None or len(empresa_id)<=1:
                logger.warning(f"No customer empresa Id present.")
                return {
                        'statusCode': 400,
                        'body': json.dumps({'received': False})
                }
            messageId = body_value.get('data').get('messageId')
            if messageId is None or len(messageId)<=1:
                logger.warning(f"Not a valid message.")
                return {
                        'statusCode': 400,
                        'body': json.dumps({'received': False})
                }            
            customer_contact_number = body_value.get('data').get('id')
            if customer_contact_number is None or len(customer_contact_number)<=1:
                logger.warning(f"Customer number is not valid")
                return {
                        'statusCode': 400,
                        'body': json.dumps({'received': False})
                }
            message = body_value.get('data').get('Transcript')
            if len(message)<=3: #Too short text does not required to perform sensitive analysis
                logger.info(f"Log message {message} is too short")
                return {
                    "received": True,
                    "message": "Too short to perform sensitive analysis"
                }
            agent_id, connection_id=worker(messageId, customer_contact_number, empresa_id)
            if agent_id is None or connection_id is None:
                logger.warning("No agent available at this moment. Wait sometime!!!")
                return {
                    "message" : f"No agent available at this moment. Wait sometime!!!"
                }
            else:
                logger.info(f"User is {customer_contact_number} has already initated the conversation. use the already connected agent.")  
            
            payload = json.dumps({
                "name": "admin",
                "text": f"""{message}""",   
                "customer_contact_number": customer_contact_number,
                "agent_id" :agent_id,  
                "connection_id":connection_id,
                "empresa_id" : empresa_id,
                "messageId" : messageId,
                "direction": "D",
                "id": customer_contact_number
            })
            headers = {
                    'Content-Type': 'application/json'
            }
            #Call Sentiment Endpoint
            logger.info(f"Calling wpadminmod for performing sentiment Analysis on user text {payload}")
            
            try:
                start = time.time()
                response = session.post(url,headers=headers, data=payload, timeout=(5,60))
                response.raise_for_status()
                logger.info(f"API sentiment analysys call time:  {time.time() - start}")
            except requests.exceptions.ConnectTimeout:
                print("Connection timeout")
                raise
            except requests.exceptions.ReadTimeout:
                print("Read timeout")
                raise
            except requests.exceptions.RequestException as e:
                print(f"HTTP error: {e}")
                raise
            #response = requests.request("POST", url, headers=headers, data=payload)
            logger.info(f"Sentiment Analysis is completed. {response}")
            if response.ok:
                logger.info(f"Get sentiment response from wpadminmod service. Sentiment Response : {response.text}")
                websocket_object=json.loads(response.text)
                if websocket_object is None or websocket_object['statusCode']==400:
                    logger.warning(f"No Data found from sentiment analyis output for message {message}")
                    #websocket_payload_json=json.loads(websocket_object['body'])
                    dummy_body={
                                    "userID": "admin",
                                    "sentiment": "NEUTRAL",
                                    "sentiment_score": {
                                        "Positive": 0.0,
                                        "Negative": 0.0,
                                        "Neutral": 0.0,
                                        "Mixed": 0.0
                                    },
                                    "dominant_language": [
                                        {
                                            "LanguageCode": "en",
                                            "Score": 0.0
                                        }
                                    ],
                                    "entities": [
                                    ],
                                    "user_text": f"{message}",
                                    "messageId": f"{messageId}",
                                    "id": f"{customer_contact_number}",
                                    "customer_contact_number": f"{customer_contact_number}",
                                    "agent_id": f"{agent_id}",
                                    "empresa_id": f"{empresa_id}"
                                    }
                    websocket_payload = json.dumps({
                        "statusCode":400,
                        "body": json.dumps(dummy_body),
                        "sentiment": "",
                        "sentiment_summary": "",
                        "language": "",
                        "suggestion": "",
                        "direction":"D",
                        "agent_id": agent_id,
                        "customer_contact_number": customer_contact_number,
                        "connection_id": connection_id 
                    })
                    try:
                        start=time.time()
                        response = session.post(url_websocket, headers=headers, data=websocket_payload, timeout=(3,10))
                        response.raise_for_status()
                        print(f"API call websocket duration {time.time()-start}")
                    except requests.exceptions.ConnectTimeout:
                        print("Connection timeout from websocket connection")
                        raise
                    except requests.exceptions.ReadTimeout:
                        print("Read timeout from websocket connection")
                        raise
                    except requests.exceptions.RequestException as e:
                        print(f"HTTP error when connecting websocket connection: {e}")
                        raise
                    #response = requests.request("POST", url_wehsocket, headers=headers, data=websocket_payload)
                    if response.ok:
                        return {
                            'statusCode': 200,
                            'body': json.dumps({'received': True})
                        }
                    else:
                        logger.error("Failed to push message to websocket for displaying users.")
                        return {
                            'statusCode': 400,
                            'body': json.dumps({'received': False})
                        }
                websocket_payload = json.dumps({
                    "statusCode":websocket_object['statusCode'],
                    "body": websocket_object['body'],
                    "sentiment": websocket_object['sentiment'],
                    "sentiment_summary": "",
                    "language": websocket_object['language'],
                    "suggestion": websocket_object['suggestion'],
                    "direction":"D",
                    "userID": "",
                    "agent_id": agent_id,
                    "customer_contact_number": customer_contact_number,
                    "connection_id": connection_id
                })
                try:
                    try:
                        start=time.time()
                        session.post(url_websocket, headers=headers, data=websocket_payload, timeout=(5,10))
                        #Fire and forget
                        logger.info(f"API calling time Websocket with value {time.time()-start}")
                        #response = requests.request("POST", url_wehsocket, headers=headers, data=websocket_payload)
                        if response.ok:
                            # Return success response
                            return {
                                'statusCode': 200,
                                'body': json.dumps({'received': True})
                            }
                        else:
                            logger.error(f"Websocket service is down or not working as expected.")
                            # Return success response
                            return {
                                'statusCode': 400,
                                'body': json.dumps({'message': "Message Websocket service is down"})
                            }
                    except requests.exceptions.RequestException as e:
                        print("Webhook call failed:", str(e))
                    except requests.exceptions.ConnectTimeout:
                        print("Connection timeout from websocket connection")
                        raise
                    except requests.exceptions.ReadTimeout:
                        print("Read timeout from websocket connection")
                        raise
                    except requests.exceptions.RequestException as e:
                        print(f"HTTP error when connecting websocket connection: {e}")
                        raise
                except Exception as es:
                    logger.error(f"Error occured to call Websocket service. {es}")   
            else:
                logger.error("wpadminmod is not active. Contact Administrator for restart the service or fix the error.")
                # Return success response
                return {
                    'statusCode': 400,
                    'body': json.dumps({'message': "Sentiment analysis service is not working. Check the log."})
                }
            
            # Add your business logic here
            # For example, update database, send notifications, etc.   
        elif event_type == 'payment.failed':
            # Handle failed payment
            logger.warning(f"Invalid event type {event_type}")
            return {
                'statusCode': 400,
                'body': json.dumps({'error': 'Invalid event type {event_type} '})
            }     
        else:
            logger.warning(f"Invalid event type {event_type}")
            return {
                'statusCode': 400,
                'body': json.dumps({'error': 'Invalid event type {event_type} '})
            }  
    except json.JSONDecodeError:
        logger.error("Json validation failed.")
        return {
            'statusCode': 400,
            'body': json.dumps({'error': 'Invalid JSON payload'})
        }
    except Exception as e:
        logger.error(f"Error processing webhook: {e}")
        import traceback
        error_message = traceback.format_exc()
        print("Detailed error:\n", error_message) 
        return {
            'statusCode': 500,
            'body': json.dumps({'error': 'Internal server error'})
        } 
    finally:
        session.close()


if __name__ == "__main__":
    event= {
                "headers": {
                    "Content-Type": "application/json",
                    "x-webhook-signature": "f462e5a9940f5bd1621762b834e2db3239e18f439ffb48e4e5604505d807887a"
                },
                "body": {
                            "empresaID" : "787878787",
                            "agenteID" :  "",
                            "data": {
                                "type": "text",
                                "messageId": "aasddddddd",
                                "Transcript": "Carnataki flute have 8 blowing hole",
                                "timestamp" : "2026-01-21T09:59:06.167Z",
                                "id" : "88888888"
                            }
                        }
    }
    context = {}
    lambda_handler(event, context)
