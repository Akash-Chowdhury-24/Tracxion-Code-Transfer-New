import chalicelib.websocket_services as ws_opr_service
#from chalicelib.crate_db_operation import
import json
from datetime import datetime

from chalicelib.websocket_service import WebSocketService
ws_service = WebSocketService(ws_opr_service)

ws_opr_service.list_usernames()