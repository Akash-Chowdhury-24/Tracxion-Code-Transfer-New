from chalice import Chalice, CORSConfig
import chalicelib.websocket_services as ws_opr_service

#from chalicelib.crate_db_operation import
import json
from datetime import datetime
import time
from chalicelib.websocket_service import WebSocketService
import logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

app = Chalice(app_name='chalice-websocket-cratedb')
app.debug = True

#all_real_time_users_storage = dict()
#db_service = CrateDBService()
ws_service = WebSocketService(ws_opr_service)

#Cache for storing real-time Users
#users_cache = ws_opr_service.LambdaThreadSafeDictForRealTimeUsers()
# -------------------------
# WebSocket Handlers
# -------------------------

app.experimental_feature_flags.update([
    'WEBSOCKETS'
])

# CORS Support
cors_config = CORSConfig(
    allow_origin='*',
    allow_headers=['X-Special-Header', 'Content-Type', 'Authorization'],
    max_age=600,
    expose_headers=['X-Special-Header'],
    allow_credentials=True
)

@app.on_ws_connect()
def on_connect(event):
    event_dict = event.to_dict()
    logger.info(f"Connecting to Wss {event_dict}")
    connection_id = event.connection_id
    qs_params = event_dict.get("queryStringParameters") or {}
    print(qs_params)
    user_type = qs_params.get("usertype")
    if user_type is None:
        user_type = 'E'
    if user_type=='E':
        customer_number = qs_params.get("id")
        agent_id = qs_params.get("agentId")
    else:
        customer_number="00000000"
        agent_id = qs_params.get("agentId")
    #wss://hxybml9v9l.execute-api.ap-south-1.amazonaws.com/api/?agentId=supervisor1&usertype=S
    #agent_id = qs_params.get("agentId")
    #customer_number=qs_params.get("empresaID") #empresaID=59323825792

    logger.info(f"User ID: {agent_id} User type {user_type} connection Id {connection_id}")

    if not agent_id:
        from chalice import WebsocketDisconnectedError
        raise WebsocketDisconnectedError("Required agentId")

    #agent_id = event.query_string_parameters.get("agentId")
    logger.info(f"Agent ID {agent_id}")
    if not agent_id:
        raise Exception("agent_id is required")
    Item = {
        'agent_id': agent_id,
        'connection_id': connection_id,
        'customer_number' : customer_number,
        'user_type': user_type
    }

    is_connection=ws_opr_service.save_connection_updates(Item)
    if is_connection:
        logger.info(f"Established new connection for agent {agent_id}  and customer {customer_number} conection id {connection_id} successfully")
    else:
        raise Exception("No slot available for new connection.")
    time.sleep(1)
    logger.info("Exiting on_connect")

@app.on_ws_disconnect()
def on_disconnect(event):
    try:
        event_dict = event.to_dict()
        logger.info(f"Disconnecting Wss {event_dict} Preparing on_disconnect method {event.connection_id}")
        connection_id = event.connection_id
        qs_params = event_dict.get("queryStringParameters") or {}
        agent_id = qs_params.get("agentId")

        logger.info(f"Deleting Agent ID: {agent_id}")
        Item = {
            'agent_id': agent_id,
            'connection_id': connection_id
        }
        ws_opr_service.delete_connection(Item)
        logger.info(f"Connecton id {event.connection_id} deleted successfully.")
    except Exception as e:
        logger.error(f"Error occured when removing connection {e}")
    logger.info("Connection deleted.")

@app.on_ws_message()
def on_message(event):
    logger.info("Initiating on_message in websocket")
    try:
        event_dict = event.to_dict()
        logger.info(f"Messages Wss {event_dict}")
        qs_params = event_dict.get("queryStringParameters") or {}
        agent_id = qs_params.get("agentId")
        logger.info(f"Inside on_message method. Sending message {event.connection_id} Agent {agent_id}")
        body = json.loads(event.body)
        target_agent=body.get('target_agent')
        message = body.get('message')
        logger.info(f"Target agent {target_agent} and message {message}")
        if not target_agent:
            logger.info("No target_agent found")
            return
        #Get the Agent Details from CrateDB
        agent_id, connection_id=ws_opr_service.get_agent_on_connection(target_agent)
        logger.info(f"Sending message to agent {agent_id} of Connection id {connection_id}")
        logger.info(f"Event connection {event.connection_id} and connection from database {connection_id}")
        ws_service.send(
            connection_id,
            {
                "type": "echo",
                "message": event.body
            }
        )
    except Exception as e:
        logger.error(f"Error occurred when sending message to websocket {e}")
    logger.info(f"Message Send Completed {agent_id}")

# -------------------------
# REST Endpoint
# -------------------------


@app.route('/remove/{user_key}', methods=['DELETE'], cors=cors_config)
def remove_user(user_key):
    logger.info(f"Removing user {user_key} from real time storage")
    return user_key
    # deleted_user=users_cache.pop(user_key)
    # if deleted_user is not None:
    #     return {
    #         "status" : "200",
    #         "body": f"User {user_key} is removed"
    #     }
    # else:
    #     return {
    #         "status": "200",
    #         "body": f"User {user_key} not found"
    #     }

@app.route('/{user_key}', methods=['GET'])
def index(user_key):
    Item = {
        'agent_id': 'aaaagentsfgd12112jfjskdf2',
        'connection_id': 'Q1',
        'customer_number': '91281283443535',
        'user_type':'S'
    }
    is_connection = ws_opr_service.save_connection_updates(Item)
    if is_connection:
        print('Performed Well')
    # if user_key=='all':
    #     return {'ping': 'pong', 'len': len(users_cache), 'user': users_cache.items()}
    # user=users_cache.get(user_key)
    # return {'ping': 'pong', 'len': len(users_cache), 'user': user}



@app.route('/publish', methods=['POST'], content_types=['application/json'])
def publish():
    """
    Push data to all connected websocket clients
    """
    payload = app.current_request.json_body
    logger.info(f"Record received for user {payload} type: {type(payload)}")

    customer_contact_number = payload.get('customer_contact_number')
    message_id=payload.get('messageId')
    connection_id=payload.get('connection_id')
    payload_body=json.loads(payload.get('body'))
    agent_id =  payload_body['agent_id']
    userId= payload_body['id']
    message_id=payload_body['messageId']
    print(f"Agent ID {agent_id} userId {userId} message Id {message_id}")
    # agent_id=payload['agent_id']
    # userId = payload['id']
    # print(f"Agent ID {agent_id} userId {userId}")

    try:
        logger.info(f"record = {payload}")
        logger.info(f"Customer number {customer_contact_number}")

        # Store in Cache
        #ws_opr_service.insert_data_in_cache(customer_contact_number=customer_contact_number,message_id=message_id, agent_id=agent_id,userId=userId, connection_id=connection_id)
        #list_of_active_connections= ws_opr_service.list_connections(user_cache=users_cache)
        if connection_id is None:
            list_of_active_connections = ws_opr_service.list_connections(agent_id=agent_id, message_id=message_id)
        else:
            logger.info(f"Sending message to agent{agent_id} message Id {message_id} connection id {connection_id}")
            list_of_active_connections=[connection_id]

        #Get Supervisor connection ID
        try:
            super_connection=ws_opr_service.get_supervisor_connection()
            logger.info(f"Supervisor connection id {super_connection}")
            if super_connection:
                list_of_active_connections.append(super_connection[0])
        except Exception as sup_err:
            logger.warning(f"Could not get supervisor connection: {sup_err}")
        logger.info(f"All connection {list_of_active_connections}")

        # Broadcast to WebSocket
        ws_service.broadcast({
            "type": "data",
            "payload": payload
        }, list_of_active_connections)
        logger.info(f"Message send to Customer {customer_contact_number}")
    except Exception as e:
        logger.error(f"Error sending message to websocket to UI. {e}")
        return {
            "status": "failed"
        }
    return {"status": "sent"}


# event={
#   "statusCode": 200,
#   "body": {
#     "userID": "admin",
#     "sentiment": "NEUTRAL",
#     "sentiment_score": {
#       "Positive": 0.01093014981597662,
#       "Negative": 0.09648404270410538,
#       "Neutral": 0.891532838344574,
#       "Mixed": 0.001052984269335866
#     },
#     "dominant_language": [
#       {
#         "LanguageCode": "en",
#         "Score": 0.9957380294799805
#       }
#     ],
#     "detect_pii_entities": [
#       {
#         "Score": 0.9981645941734314,
#         "Type": "ADDRESS",
#         "BeginOffset": 25,
#         "EndOffset": 33
#       },
#       {
#         "Score": 0.9997783303260803,
#         "Type": "ADDRESS",
#         "BeginOffset": 37,
#         "EndOffset": 44
#       }
#     ],
#     "entities": [
#       "Shanghai",
#       "kolkata"
#     ],
#     "user_text": "I missed the flught from Shanghai to kolkata. What is any other flight?",
#     "messageId": "10005",
#     "id": "11132",
#     "customer_contact_number": "11132",
#     "agent_id": "Stephan1",
#     "empresa_id": "1112"
#   },
#   "sentiment": "NEUTRAL",
#   "sentiment_summary": {
#     "Positive": 0.01093014981597662,
#     "Negative": 0.09648404270410538,
#     "Neutral": 0.891532838344574,
#     "Mixed": 0.001052984269335866
#   },
#   "language": "en",
#   "suggestion": [
#     "Could you tell me what caused you to miss your flight from Shanghai to Kolkata?",
#     "Did you check with the airline for any later flights on the same day?",
#     "Would you like me to help you find alternative flights from Shanghai to Kolkata?"
#   ],
#   "direction": "D",
#   "customer_contact_number": "11132"
# }
