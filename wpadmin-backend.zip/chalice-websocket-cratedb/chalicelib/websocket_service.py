import boto3
import json
import os
from botocore.exceptions import ClientError

from chalicelib.crate_db_operation import logger

class WebSocketService:
    def __init__(self, db_service):
        self.db = db_service
        self.api = boto3.client(
            "apigatewaymanagementapi",
            endpoint_url="https://****.execute-api.ap-south-1.amazonaws.com/api/",
            region_name="ap-south-1"
        )

    def send(self, connection_id, message):
        logger.info(f"Sending msg to {connection_id}")
        try:
            self.api.post_to_connection(
                ConnectionId=connection_id,
                Data=json.dumps(message).encode("utf-8")
            )
            logger.info(f"msg sent successfully")
        except ClientError as e:
            print(f"Error found when sending messages : {e}")
            if e.response["Error"]["Code"] == "GoneException":
                print(f"Connection {connection_id} is gone. Cleaning up.")
                print(e)
                import chalicelib.websocket_services as ws_opr_service
                ws_opr_service.delete_connection({'connection_id': connection_id})
            else:
                print(f"Error occurred when sending msg to websocket")
                raise

    def broadcast(self, message, list_connections):
        logger.info(f"Start broadcasting message All connections are {list_connections}")
        if len(list_connections)>0:
            for cid in list_connections:
                try:
                    logger.info(f"Message {message} is trying to send {cid}")
                    self.send(cid, message)
                    logger.info(f"Message sent completed")
                except Exception as e:
                    logger.error(f"Error occurred when sending message for {cid}: {e}")
        else:
            logger.warning(f"No Connection found for sending messages.")
        logger.info(f"Broadcast done")