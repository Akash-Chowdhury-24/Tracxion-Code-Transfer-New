from crate import client
import urllib3
class CrateDBService:
    def __init__(self):
        self.conn = client.connect(
        servers=[""],
        username="admin",
        password= "",
        timeout=urllib3.Timeout(connect=5.0,read=10.0),
        schema="crate",
        verify_ssl_cert=True
        )
        self.cursor = self.conn.cursor()
        self._init_tables()

    def test(self):
        print("test")  
        
    def _init_tables(self):
        self.cursor.execute("""
        CREATE TABLE IF NOT EXISTS crate.ws_connections (
            connection_id STRING PRIMARY KEY
        )
        """)

        self.cursor.execute("""
        CREATE TABLE IF NOT EXISTS crate.realtime_data (
            value DOUBLE,
            timestamp TIMESTAMP
        )
        """)

    # --------------------
    # WebSocket connections
    # --------------------

    def save_connection(self, connection_id):
        self.cursor.execute(
            "INSERT INTO crate.ws_connections (connection_id) VALUES (?)",
            (connection_id,)
        )

    def remove_connection(self, connection_id):
        self.cursor.execute(
            "DELETE FROM crate.ws_connections WHERE connection_id = ?",
            (connection_id,)
        )

    def list_connections(self):
        self.cursor.execute("SELECT connection_id FROM crate.ws_connections")
        return [row[0] for row in self.cursor.fetchall()]

    # --------------------
    # Data storage
    # --------------------

    def insert_data(self, record):
        self.cursor.execute(
            "INSERT INTO crate.realtime_data (value, timestamp) VALUES (?, ?)",
            (record["value"], record["timestamp"])
        ) 