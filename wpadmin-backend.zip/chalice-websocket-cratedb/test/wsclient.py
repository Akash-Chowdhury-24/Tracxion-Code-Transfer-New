import websocket

ws = websocket.create_connection("wss://hxybml9v9l.execute-api.ap-south-1.amazonaws.com/api/")
print("Connected")

ws.send("ping")
print("Sent ping")

result = ws.recv()
print("Received:", result)

ws.close()
