import json
from chalice.test import Client
from app import app

def test_ws_message():
    with Client(app) as client:
        response = client.lambda_.invoke(
            "on_message",
            {
                "requestContext": {
                    "connectionId": "abc123",
                    "routeKey": "$default"
                },
                "body": '{"message":"hello"}',
                "isBase64Encoded": False
            }
        )

        body = json.loads(response.payload["body"])
        assert body["echo"]["message"] == "hello"