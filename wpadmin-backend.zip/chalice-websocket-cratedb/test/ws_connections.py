import json
# from chalice.test import Client
# from app import app
import chalicelib.websocket_services as ws_opr_service
def test_new_connection():
    print("Starting test of new ws connections")
    Item = {
        'agent_id': "agent_01",
        'connection_id': "Connection-05"
    }
    response=ws_opr_service.save_connection(Item)
    body = json.loads(response.payload["body"])
    assert body["echo"]["message"] == "hello"


def test_delete_connection():
    print("Deleting existing ws connection")
    Item = {
        'agent_id': "agent_01",
        'connection_id': 'Connection-05'
    }
    res=ws_opr_service.delete_connection(Item)
    print("Delete existing connection")

def test_send_message():
    print("Send message")
    target_agent='agent_01'
    connection_id='Connection-05'
    # Get the Agent Details from CrateDB
    connection_id_agent = ws_opr_service.get_agent_on_connection(target_agent)
    print(f"Connection_id_agent {connection_id_agent}")
    ws_opr_service.send(
        connection_id,
        {
            "type": "echo",
            "message": "msssa"
        }
    )