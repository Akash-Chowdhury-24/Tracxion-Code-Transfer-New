import threading
import time
import datetime
from sqlite3 import sqlite_version
from urllib3.exceptions import ConnectTimeoutError, ReadTimeoutError
import logging
import urllib3
from crate import client
import math
import string
import logging
import redis

logger = logging.getLogger()
logger.setLevel(logging.INFO)

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def create_redis_connection():
    print("Getting Redis Connection Pool")
    redis_pool = redis.ConnectionPool(
        host='',
        port=12391,
        password="",
        db=0,
        username="default",
        max_connections=10,  # keep small for Lambda
        socket_connect_timeout=2,
        socket_timeout=2,
        decode_responses=True  # returns str instead of bytes
    )
    redis_client = redis.Redis(connection_pool=redis_pool)
    return redis_client

def create_crate_connection():
    return client.connect(
        servers=[""],
        username="admin",
        password= "",
        timeout=urllib3.Timeout(connect=5.0,read=10.0),
        schema="crate",
        verify_ssl_cert=True,
    )

class RedisConnectionPool:
    def __init__(self, creator):
        self._creator = creator
        self._pool = []
        self._in_use = set()

    def acquire(self,timeout=None):
        client=self._creator()
        self._in_use.add(client)
        return client

class UpdateInProgress(Exception):
    pass

class SimpleConnectionPool:
    def __init__(self, creator, maxsize=10, **param):
        self._creator = creator
        self._maxsize=maxsize
        self._lock=threading.Lock()
        self._pool = []
        self._in_use = set()
        self._param=param

    def encrypt(self, unencrypted_text, key):
        # Define character groups
        lower = string.ascii_lowercase
        upper = string.ascii_uppercase
        digits = string.digits
        specials = string.punctuation
        all_symbols = lower + upper + digits + specials

        key_sum = sum(ord(c) for c in key)  # derive a numeric key for shifting

        encrypted = ''
        for c in unencrypted_text:
            if c in all_symbols:
                idx = all_symbols.index(c)
                # Deterministic (but not secure) shift
                e_idx = (idx + key_sum) % len(all_symbols)
                encrypted += all_symbols[e_idx]
            else:
                encrypted += c  # leave other chars unchanged
        return encrypted

    def decrypt(self, text, key):
        lower = string.ascii_lowercase
        upper = string.ascii_uppercase
        digits = string.digits
        specials = string.punctuation
        all_symbols = lower + upper + digits + specials

        key_sum = sum(ord(c) for c in key)

        decrypted = ''
        for c in text:
            if c in all_symbols:
                idx = all_symbols.index(c)
                d_idx = (idx - key_sum) % len(all_symbols)
                decrypted += all_symbols[d_idx]
            else:
                decrypted += c
        return decrypted

    def acquire(self, timeout=None):
        end_time=None
        if timeout is not None:
            logger.info(f"timeout {timeout}")
            end_time=time.time() + timeout

        while True:
            with self._lock:
                if self._pool:
                    conn = self._pool.pop()
                    self._in_use.add(id(conn))
                    logger.info("Return connection from step 1")
                    return conn

                if len(self._in_use) < self._maxsize:
                    conn = self._creator()
                    self._in_use.add(id(conn))
                    logger.info("Return connection from step 2")
                    return conn
            logger.info(f"Backup connection size {len(self._pool)}")
            if end_time is not None and time.time() > end_time and len(self._pool)==1:
                logger.info(f"End time {end_time}")
                logger.info(f"Current time {time.time()}")
                raise TimeoutError("Connection pool timeout")
            time.sleep(0.01)

    def release(self, conn):
        with self._lock:
            self._in_use.discard(id(conn))
            self._pool.append(conn)

    def close_all(self):
        with self._lock:
            for conn in list(self._pool):
                try:
                    conn.close()
                finally:
                    self._pool.remove(conn)
            for cid in list(self._in_use):
                # We may need a way to map id->connection; implement if available
                pass

#Usages
param='qmark'
print("Initiating crateDB connection")
pool = SimpleConnectionPool(create_crate_connection, maxsize=8, param=param)
redis_connection_obj = RedisConnectionPool(create_redis_connection).acquire(timeout=10)

################WebSocket Operation#################################
def _init_tables(self):
    self.cursor.execute("""
    CREATE TABLE IF NOT EXISTS crate.ws_connections (
        connection_id STRING PRIMARY KEY
    )
    """)

    self.cursor.execute("""
    CREATE TABLE IF NOT EXISTS crate.realtime_data (
        value DOUBLE,
        timestamp TIMESTAMP
    )
    """)

# ----------------------
# WebSocket connections
# ----------------------
def save_connection(self, connection_id):
    self.cursor.execute(
        "INSERT INTO crate.ws_connections (connection_id) VALUES (?)",
        (connection_id,)
    )

def remove_connection(self, connection_id):
    self.cursor.execute(
        "DELETE FROM crate.ws_connections WHERE connection_id = ?",
        (connection_id,)
    )

def list_connections(self):
    self.cursor.execute("SELECT connection_id FROM crate.ws_connections")
    return [row[0] for row in self.cursor.fetchall()]

# -------------------
# Redis Connection
# -------------------
def delete_connections(agent_id, customer_number):
        try:
            conn = pool.acquire(timeout=5)
            conn.autocommit=False
            cursor = conn.cursor()

            #Step 1
            crate_schema_name = cursor.connection.client.schema
            sql_select_agent=f"""SELECT distinct conversation_id, agent_id, address_to 
                        FROM {crate_schema_name}.realtime_agents_presence WHERE agent_id=? AND status=?"""
            cursor.execute(sql_select_agent, (agent_id, False,))
            result = cursor.fetchall()
            conversation_id = result[0][0]
            agent_id = result[0][1]
            customer_number = result[0][2]
            from datetime import datetime, timezone
            utc = datetime.now(timezone.utc)
            print(f"Agent {agent_id} customer_number {customer_number}")
            #agent_id='9e291c50-8c9a-4780-9e55-9bae90351c96'
            #customer_number='593984660579'
            print(f"Agent {agent_id} customer_number {customer_number}")
            
            #Step 2
            sql_select_connection_id=f"""SELECT connection_id FROM {crate_schema_name}.ws_connections WHERE user_id=? AND customer_contact_number=?"""
            cursor.execute(sql_select_connection_id, (agent_id, customer_number, ))
            res_connection=cursor.fetchall()
            connection_id=res_connection[0][0]
            
            #Step 3
            sql_delete_query=f"""UPDATE {crate_schema_name}.ws_connections SET disconnected_at=? WHERE connection_id=? AND user_id=? AND customer_contact_number=?"""
            res=cursor.execute(sql_delete_query, (utc,connection_id,agent_id,customer_number,))
            
            #Step 4
            delete_connection_from_redis(connection_id=connection_id)
            
            #Step 5
            sql_update_agent=f"""UPDATE {crate_schema_name}.realtime_agents_presence SET status=? WHERE agent_id=?"""
            cursor.execute(sql_update_agent, (True, agent_id,))
            logger.info(f"Agent {agent_id} is reset to accept new connections")
        except ConnectTimeoutError:
            logger.error(f"Error occur when inserting company details ")
        except ReadTimeoutError:
            logger.info('Read timeout: server did not respond within timeout period')
        except Exception as e:
            logger.info(f"Error occured when selecting active agent {e}")
        finally:
            pool.release(conn)

def delete_connection_from_redis(connection_id):
    logger.info("Deleteing connection")
    lock_key=f"{connection_id}"
    
    def delete_connection_id(connection_id):
        logger.info(f"Deleting Connection ID {connection_id}")
        key = connection_id
        LUA_SCRIPT_DEL_CONNECTION_ID_INACTIVE_SET = """
            local set_key = KEYS[1]
            local members = redis.call("SMEMBERS", set_key)
            for _, key in ipairs(members) do
                redis.call("DEL", key)
            end
            redis.call("DEL", set_key)
            return #members
            """
        LUA_SCRIPT_DELETE_CONNECTION_ID_FRM_CACHE=f"""
                local key = KEYS[1]
                if redis.call("EXISTS", key) == 1 then
                    redis.call("DEL", key)
                    return 1
                else
                    return 0
                end
        """
        result=redis_connection_obj.eval(
            LUA_SCRIPT_DELETE_CONNECTION_ID_FRM_CACHE,
            1,
            key
        )
        if result==0:
            deleted=redis_connection_obj.eval(
                LUA_SCRIPT_DEL_CONNECTION_ID_INACTIVE_SET,
                1,
                "inactive_connections"
        )
        return result, deleted
        #  # lock_key = f"lock:update:{connection_id}"       
        # acquired=redis_connection_obj.delete(lock_key)
        # return acquired, lock_key
    
    LOCK_TTL = 30 
    # if not acquired:
    #     raise UpdateInProgress(f"Update already running for ID {lock_key}")
    def insert_redis_using_lua(connection_id):
        logger.info("Insert data......")
        LUA_SCRIPT = """
            local key = KEYS[1]
            if redis.call("EXISTS", key) == 0 then
                redis.call("HSET", key, unpack(ARGV))
                return 1
            else
                return 0
            end
            """
        redis_client=redis_connection_obj.acquire(timeout=3)
        key=connection_id
        values={"agent_id":'a',"age":10}
        argv = []
        for k, v in values.items():
            argv.extend([k, v])
        result = redis_client.eval(
                LUA_SCRIPT,
                1,              # number of KEYS
                key,     # KEYS[1]
                *argv        # ARGV[1]
            )
        return result
        logger.info("Test successful")
        
    def acquire_redis_lock():
        # lock_key = f"lock:update:{connection_id}"       
        acquired=redis_connection_obj.delete(lock_key)
        return acquired, lock_key
    
    result, deleted = delete_connection_id(connection_id=connection_id)
    print(result, deleted)
    
        
# --------------------
# Data storage
# --------------------
def insert_data(record):
    logger.info(f"Initiating push message insert to websocket Users")
    conn = pool.acquire(timeout=5)
    try:
        conn.autocommit = False
        cursor=conn.cursor()
        crate_schema_name = cursor.connection.client.schema
        cursor.execute(
        f"""INSERT INTO {crate_schema_name}.realtime_data (value, timestamp) VALUES (?, ?)""",
        (record["value"], record["timestamp"]))
        # sql_messages=f"""insert into crate.messages (message_id,sender_id, content, message_type, status, sentiment, entities, timestamp, tenant_id,
        # conversation_id, direction, provider_message_id)
        # values (?,?,?,?,?,?,?,?,?,?,?,?)"""
        #params = ()
        conn.commit()
    except ConnectTimeoutError:
        logger.error(f"Error occur when inserting company details ")
    except ReadTimeoutError:
        logger.info('Read timeout: server did not respond within timeout period')
    except Exception as e:
        logger.info(f"{e}")
    finally:
        pool.release(conn)


def wsinsert(connection_id, data):
    logger.info(f"Initating websocket Users")
    conn = pool.acquire(timeout=5)
    try:
        cursor = conn.cursor()
        cursor.execute(
            "INSERT INTO crate.wsmessage (connection_id, message, timestamp) VALUES (?, ?, ?)",
            (connection_id, data, datetime.utcnow())
        )
        conn.commit()
        logger.info("inserted values............")
    except ConnectTimeoutError:
        logger.error(f"Error occur when inserting company details ")
    except ReadTimeoutError:
        logger.info('Read timeout: server did not respond within timeout period')
    except Exception as e:
        logger.info(f"{e}")
    finally:
        pool.release(conn)


def _insert_ws_msg(msg):
    logger.info(f"Initating websocket Users")
    conn = pool.acquire(timeout=5)
    try:
        cur=conn.cursor()
        SQL_INSERT_USERS="insert into crate.users (id, username, created_at) values (?,?,?)"
    except ConnectTimeoutError:
        logger.error(f"Error occur when inserting company details ")
    except ReadTimeoutError:
        logger.info('Read timeout: server did not respond within timeout period')
    except Exception as e:
        logger.info(f"{e}")
    finally:
        pool.release(conn)


def _execute(query, params, fetch=False):
    logger.info(f"Executing {query} SQL query for websocket Users")
    conn = pool.acquire(timeout=5)
    try:
        cur=conn.cursor()
        cur.execute(query, params or ())
        if fetch:
            return cur.fetchall()
        return None
    except ConnectTimeoutError:
        logger.error(f"Error occur when executing query {query}")
    except ReadTimeoutError:
        logger.error('Read timeout: server did not respond within timeout period')
    except Exception as e:
        logger.error(f"{e}")
    finally:
        pool.release(conn)

def insert_agent_available(agent_params):
    logger.info("Inserting agent details into database")
    try:
        conn = pool.acquire(timeout=5)
        cursor = conn.cursor()
        crate_schema_name = cursor.connection.client.schema
        SQL_AGENT_INSERT=f"""INSERT INTO {crate_schema_name}.realtime_agents_presence (conversation_id, 
                            source, 
                            account, 
                            region, 
                            provider, 
                            address_to, 
                            address_from, 
                            status, 
                            last_seen, 
                            session_id, 
                            device_type,
                            ip_address, 
                            metadata, 
                            updated_at, 
                            topic_name, 
                            agent_id, 
                            agent_name, 
                            agent_email, 
                            agent_queue_id) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT DO NOTHING"""
        cursor.execute(SQL_AGENT_INSERT, agent_params)
        logger.info("agent details inserted successfully")   
         
    except ConnectTimeoutError:
        logger.error(f"Error occur when inserting company details ")
    except ReadTimeoutError:
        logger.info('Read timeout: server did not respond wihtin timeout period')
    except Exception as e:
        logger.info(f"{e}")
    finally:
        pool.release(conn)

#########################
def insert_messages(message_body,message_id):
    logger.info("Event data inserting into CrateDB database.")
    try:
        conn = pool.acquire(timeout=5)
        cursor = conn.cursor()
        crate_schema_name = cursor.connection.client.schema
        chat_id = "1" #Need to work 
        sender_id="+11111111" #Need to work
        content=message_body['user_text']
        media_url="" #Need to work
        message_type="Text" #Need to capture from AWS comprehend response/
        status="u" #User type
        sentiment=message_body['sentiment']
        entities=message_body['entities']
        from datetime import datetime, timezone
        utc = datetime.now(timezone.utc)
        params=(message_id, 
                chat_id,
                sender_id,
                content,
                media_url,
                message_type,
                status,
                sentiment,
                entities,
                utc)
        insert_sql=f"""insert into {crate_schema_name}.messages (message_id, chat_id, sender_id,
        content, media_url, message_type, status, sentiment, entities, timestamp) values (?,?,?,?,?,?,?,?,?,?)"""
        cursor.execute(insert_sql, params)
        logger.info("Chat details inserted successfully")
    except ConnectTimeoutError:
        logger.error(f"Error occur when inserting company details ")
    except ReadTimeoutError:
        logger.info('Read timeout: server did not respond wihtin timeout period')
    except Exception as e:
        logger.info(f"{e}")
    finally:
        pool.release(conn)
    
