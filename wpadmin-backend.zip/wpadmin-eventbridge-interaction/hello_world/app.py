import json
import logging
from requests.auth import HTTPBasicAuth
import requests
import time
import boto3

import crate_db_operation as opr_db_opr

logger = logging.getLogger()
logger.setLevel(logging.INFO)

sqs = boto3.client('sqs')
# import PureCloudPlatformClientV2
# from PureCloudPlatformClientV2.rest import ApiException
# Set region

# Set up your Genesys Cloud environment variables
client_id = 'c96750b2-0579-469f-90ed-b356e8b72b47'
client_secret = '827WdLq3fvlU6JBmaC72EAMlFYCNtW3B-uYXvy74hGc'
environment = 'https://api.sae1.pure.cloud'  # Adjust region if required
AGENT_SQS_URL='https://sqs.ap-south-1.amazonaws.com/839393571674/wpadminavailableagentsservice'

GENESYS_API_BASE = environment
CLIENT_ID = client_id
CLIENT_SECRET = client_secret
GENESYS_AUTH_URL = "https://login.sae1.pure.cloud/oauth/token"  # change region

# response = requests.post(
#     GENESYS_AUTH_URL,
#     auth=HTTPBasicAuth(CLIENT_ID, CLIENT_SECRET),
#     data={"grant_type": "client_credentials"},
# )
# Global cache (persists across warm invocations)
_token = None
_token_expiry = 0

def get_token():
    r = requests.post(
        GENESYS_AUTH_URL,
        auth=("CLIENT_ID", "CLIENT_SECRET"),
        data={"grant_type": "client_credentials"},
        timeout=3
    )
    return r.json()["access_token"]

def get_genesys_token_second():
    global _token, _token_expiry
    now = time.time()
    # Reuse token if valid for next 180 seconds
    if _token and now < (_token_expiry - 180):
        return _token

    response = requests.post(
        GENESYS_AUTH_URL,
        auth=HTTPBasicAuth(CLIENT_ID, CLIENT_SECRET),
        data={"grant_type": "client_credentials"},
        timeout=30   # fail fast
    )

    response.raise_for_status()
    token_data = response.json()

    _token = token_data["access_token"]
    _token_expiry = now + token_data["expires_in"]

    return _token

# Configure SDK
#PureCloudPlatformClientV2.configuration.host = environment
#api_client = PureCloudPlatformClientV2.api_client.ApiClient()

def extract_agents(conversation):
    agents = []
    for participant in conversation.get("participants", []):
        if participant.get("purpose") == "agent":
            agents.append({
                "participantId": participant["id"],
                "userId": participant["userId"],
                "state": participant.get("state"),
                "connectedTime": participant.get("connectedTime"),
                "queueId": participant.get("queueId")
            })
    return agents

def get_user(user_id, token):
    url = f"{GENESYS_API_BASE}/api/v2/users/{user_id}"
    logger.info(f"inside get user {url}")
    headers = {
        "Authorization": f"Bearer {token}"
    }

    r = requests.get(url, headers=headers, timeout=30)
    r.raise_for_status()

    return r.json()

def get_conversation(conversation_id, token):
    try:
        url = f"{GENESYS_API_BASE}/api/v2/conversations/{conversation_id}"
        logger.info(f"Inside get conversation details : {url}")
        headers = {
            "Authorization": f"Bearer {token}"
        }
        r = requests.get(url, headers=headers, timeout=30)
        r.raise_for_status()
        logger.info("Process completed.........")
        return r.json()
    except Exception as e:
        logger.error(f"Error occured calling Genesys conversation {e}")

def get_agent_details_by_conversation(conversation_id, token):
    conversation = get_conversation(conversation_id, token)
    agents = extract_agents(conversation)
    agent_details = []

    for agent in agents:
        user = get_user(agent["userId"], token)
        logger.info(f"User {user}")
        agent_detail={}
        agent_detail[conversation_id] = {
            "userId": agent["userId"],
            "name": user["name"],
            "email": user.get("email"),
            "queueId": agent.get("queueId")
        }
        agent_details.append(agent_detail)
    return agent_details

def lambda_handler(event, context):
    logger.info(f"Event {event}")
    logger.info("This lambda received the event from Eventbridge and call the webhook for further processing.")
    conversation_id=event.get('detail')['eventBody']['conversationId']
    source = event.get('source') #Source
    account= event.get('account')
    region=event.get('region')
    provider=event.get('detail')['eventBody']['provider']
    address_to=event.get('detail')['eventBody']['addressTo']
    address_from=event.get('detail')['eventBody']['addressFrom']
    
    device_type=""
    last_seen= event.get('time')
    session_id=event.get('detail')['eventBody']['sessionId']
    ip_address=""
    metadata={"correlation_id" : event.get('detail')['metadata']['CorrelationId']}
    updated_at=""
    topic_name=event.get('detail')['topicName']
    logger.info(f"Topic name {topic_name}") 
    
    print(conversation_id)
    #TOKEN=get_genesys_token()   # fast after first call
    TOKEN = get_genesys_token_second()
    # Use token in API calls
    headers = {
        "Authorization": f"Bearer {TOKEN}"
    }
    agent_details=get_agent_details_by_conversation(conversation_id, TOKEN)
    logger.info("Received the agent Details.")
    agent_id=agent_details[0][conversation_id]['userId']
    
    agent_email=agent_details[0][conversation_id]['email']
    agent_queue_id=agent_details[0][conversation_id]['queueId']
    agent_name=agent_details[0][conversation_id]['name']

    if topic_name.endswith('acd.start'):
        logger.info("Initiating Allow agent {agent_id} name: {agent_name} Online {}")
        status = True  
    elif topic_name.endswith('acw'):
        logger.info("Initiating Allow agent {agent_id} name: {agent_name} offline {}")
        status = False
    logger.info(f"Agent ID: {agent_id} Agent_name: {agent_name} Agent Email: {agent_email} Agent_Queue Id: {agent_queue_id}")

    if status:
        try:   
            # Prepare message for SQS
            sqs_response = sqs.send_message(
                QueueUrl=AGENT_SQS_URL,
                MessageBody=json.dumps(agent_details[0])
            )
            logger.info("Agent Details passed to SQS successfully")
        except Exception:
            logger.error("Error pushing messages to SQS")
        
        try:
            from datetime import datetime, timezone
            updated_at = datetime.now(timezone.utc)
            #Insert available agents in database
            agent_params=(conversation_id, 
                                source, 
                                account, 
                                region, 
                                provider, 
                                address_to, 
                                address_from, 
                                status, 
                                last_seen, 
                                session_id, 
                                device_type,
                                ip_address, 
                                metadata, 
                                updated_at, 
                                topic_name, 
                                agent_id, 
                                agent_name, 
                                agent_email, 
                                agent_queue_id)
            opr_db_opr.insert_agent_available(agent_params)
            logger.info(f"Agent {agent_id} came online on conversation id {conversation_id}.")
        except Exception as e:
            logger.error("Error inserting record {e}")
    else:
        logger.info(f"Agent ID: {agent_id} Agent_name: {agent_name} Agent Email: {agent_email} Agent_Queue Id: {agent_queue_id}")
        opr_db_opr.delete_connections(agent_id, address_to)
        
    

    # try:
    #     ip = requests.get("http://checkip.amazonaws.com/")
    # except requests.RequestException as e:
    #     # Send some context about this error to Lambda Logs
    #     print(e)
    #     raise e
  
    return {
        "statusCode": 200,
        "body": json.dumps({
            "message": "Agent Added",
            # "location": ip.text.replace("\n", "")
        }),
    }

if __name__ == "__main__":
    event={}
    context={}
    #Start the 
    # event={
    # "version": "0",
    # "id": "5b0557a1-0fdc-f96a-9c23-af19480a9c0b",
    # "detail-type": "v2.detail.events.conversation.{id}.acd.start",
    # "source": "aws.partner/genesys.com/cloud/a6aa82e2-115e-41b0-9f7f-015981d83b4b/eventosdeprueba",
    # "account": "732147627748",
    # "time": "2025-04-29T17:57:11Z",
    # "region": "us-east-1",
    # "resources": [],
    # "detail": {
    #     "topicName": "v2.detail.events.conversation.07d488bb-7690-45cb-befc-6da11bef30c5.acd.start",
    #     "version": "2",
    #     "eventBody": {
    #         "eventTime": 1745949431791,
    #         "conversationId": "afd1e20f-0d99-4b27-8198-ccf5000369d8",
    #         "participantId": "9ecba6c2-4ade-4262-a40b-55f38228d253",
    #         "sessionId": "13fcf3f7-a089-4a15-bd10-faf674beda97",
    #         "mediaType": "MESSAGE",
    #         "provider": "PureCloud Messaging",
    #         "direction": "INBOUND",
    #         "addressTo": "593968825272",
    #         "addressFrom": "3de97f15-790d-4e71-a8e1-3d1cffb6b88d",
    #         "messageType": "OPEN",
    #         "queueId": "04bc707f-6fa0-405b-994c-40fda52e6ee8",
    #         "divisionId": "fa808612-7327-4e18-83e2-f30b6908e2d9"
    #         },
    #     "metadata": {
    #     "CorrelationId": "10aa9680-718a-4910-ae6e-661805b4d63f"
    #     },
    #     "timestamp": "2025-04-29T17:57:11.932Z"
    #     }
    # }

    event={
        "version": "0",
        "id": "35152702-8336-cd1e-4550-8d5b41fdd009",
        "detail-type": "v2.detail.events.conversation.{id}.acw",
        "source": "aws.partner/genesys.com/cloud/a6aa82e2-115e-41b0-9f7f-015981d83b4b/eventosdeprueba",
        "account": "732147627748",
        "time": "2025-04-29T17:57:40Z",
        "region": "us-east-1",
        "resources": [],
        "detail": {
            "topicName": "v2.detail.events.conversation.07d488bb-7690-45cb-befc-6da11bef30c5.acw",
            "version": "2",
            "eventBody": {
                "eventTime": 1745949454341,
                "conversationId": "afd1e20f-0d99-4b27-8198-ccf5000369d8",
                "participantId": "6cf7a6ac-d50b-4c9a-958d-a91808b283ea",
                "sessionId": "028de60e-8e00-4251-9511-ffd2adb4ad8a",
                "mediaType": "MESSAGE",
                "provider": "PureCloud Messaging",
                "direction": "INBOUND",
                "addressTo": "593984660579",
                "addressFrom": "3de97f15-790d-4e71-a8e1-3d1cffb6b88d",
                "messageType": "OPEN",
                "userId": "e1fb42e8-4f7b-4307-b0d4-4e15f19faf85",
                "queueId": "04bc707f-6fa0-405b-994c-40fda52e6ee8",
                "wrapupCode": "43b215ad-4309-4088-8b5c-bf72f89119dc",
                "wrapupDurationMs": 6052
            },
            "metadata": {
                "CorrelationId": "899780c8-43c3-4b37-9a1d-af2a250b50aa"
            },
            "timestamp": "2025-04-29T17:57:40.438Z"
            }
    }
    lambda_handler(event=event, context=context)