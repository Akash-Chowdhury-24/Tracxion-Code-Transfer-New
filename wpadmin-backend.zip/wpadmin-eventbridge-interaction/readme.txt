sam build
sam deploy --guided --no-fail-on-empty-changeset --stack-name wpadmin-eventbridge-interaction
sam deploy --guided --force-upload



