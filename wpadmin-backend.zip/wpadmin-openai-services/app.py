from chalice import Chalice, CORSConfig
import json
from openai import OpenAI
import re
import logging
from chalicelib import cratedb_db_opr as opr_db_opr

logger = logging.getLogger()
logger.setLevel(logging.INFO)

MODEL="gpt-4.1-mini"
client=OpenAI(
    api_key=""
)

cors_config = CORSConfig(
    allow_origin='*',
    allow_headers=['X-Special-Header', 'Content-Type', 'Authorization'],
    max_age=600,
    expose_headers=['X-Special-Header'],
    allow_credentials=True
)

app = Chalice(app_name='wpadmin-openai-services')

@app.route('/')
def index():
    return {'hello': 'world'}

@app.route('/getsummary', methods=['GET'], content_types=['application/json'], cors=cors_config)
def get_final_summary():
    try:
        request = app.current_request
        #data = request.json_body  # Parse JSON payload
        messageid = request.query_params.get('messageid') if request.query_params else None
        all_contents=opr_db_opr.select_messages(message_id=messageid)
        text_to_summarize = f"""
            {all_contents}
        """
        response = client.chat.completions.create(
            model=MODEL,   # fast + cost-effective
            messages=[
                {
                    "role": "system",
                    "content": "You are a professional text summarization assistant."
                },
                {
                    "role": "user",
                    "content": f"""
                        Summarize the following text in 5 bullet points.
                        Use clear and concise language.
                        Determine the overall sentiment of the text.
                        Sentiment must be exactly one of:
                        - POSITIVE
                        - NEGATIVE
                        - MIXED
                        - NEUTRAL
                        Rules:
                        - Add explanations.
                        - Output must be valid JSON only
                        - Answer should be in the same language in the same language of input text.
                        
                        Text:
                        \"\"\"{text_to_summarize}\"\"\"
                        """
                }
            ],
            temperature=0.3
        )
        summary = response.choices[0].message.content
        return {
            "statusCode": 200,
            "message": summary
        }
    except Exception as e:
            print(e)
            return {
                "statusCode": 400,
                "message": "Error is genenating summary OpenAI"
            }


@app.route('/getquestions', methods=['POST'], content_types=['application/json'], cors=cors_config)
def get_three_questions_on_users_comments():
    logger.info("Processing OpenAI APIs")
    try:
        request = app.current_request
        data = request.json_body  # Parse JSON payload
        user_query=data['message']
        user_query=f"""Give me three consecutive questions for user which I can ask them how {user_query}"""
        response = client.responses.create(
            model=MODEL,
            input=[{"role": "user",
                    "content": user_query}]
        )
        logger.info(f"Answer is {response.output_text}")
        questions = re.findall(r'\d+\.\s*(.*?\?)', response.output_text)
        logger.info(questions)
        qu = []
        if len(questions)==3:
            qu.append(questions[0])
            qu.append(questions[1])
            qu.append(questions[2])
        if len(questions):
            return {
                "statusCode": 200,
                "body": json.dumps({
                    "message": qu
                    # "location": ip.text.replace("\n", "")
                }),
            }
        else:
            return {
                "statusCode": 200,
                "body": json.dumps({
                    "message": "No suggestions observed on user's query"
                    # "location": ip.text.replace("\n", "")
                }),
            }
    except Exception as e:
        logger.error(f"Error occured when raising open ai call {e}")
        return {
            "statusCode": 400,
            "body": json.dumps({
                "message": "Error occured when calling LLM model"
                # "location": ip.text.replace("\n", "")
            }),
        }


