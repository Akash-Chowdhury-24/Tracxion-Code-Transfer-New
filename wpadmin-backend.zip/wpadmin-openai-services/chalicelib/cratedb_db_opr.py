from urllib3.exceptions import ConnectTimeoutError, ReadTimeoutError
import threading
import time
import datetime
#from urllib3.exceptions import ConnectTimeoutError, ReadTimeoutError
import logging
import urllib3
from crate import client
import math
import string
import logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def create_crate_connection():
    return client.connect(
        servers=[""],
        username="admin",
        password= "",
        timeout=urllib3.Timeout(connect=5.0,read=10.0),
        schema="crate",
        verify_ssl_cert=True,

    )
class SimpleConnectionPool:
    def __init__(self, creator, maxsize=10, **param):
        self._creator = creator
        self._maxsize=maxsize
        self._lock=threading.Lock()
        self._pool = []
        self._in_use = set()
        self._param=param

    def encrypt(self, unencrypted_text, key):
        # Define character groups
        lower = string.ascii_lowercase
        upper = string.ascii_uppercase
        digits = string.digits
        specials = string.punctuation
        all_symbols = lower + upper + digits + specials

        key_sum = sum(ord(c) for c in key)  # derive a numeric key for shifting

        encrypted = ''
        for c in unencrypted_text:
            if c in all_symbols:
                idx = all_symbols.index(c)
                # Deterministic (but not secure) shift
                e_idx = (idx + key_sum) % len(all_symbols)
                encrypted += all_symbols[e_idx]
            else:
                encrypted += c  # leave other chars unchanged
        return encrypted

    def decrypt(self, text, key):
        lower = string.ascii_lowercase
        upper = string.ascii_uppercase
        digits = string.digits
        specials = string.punctuation
        all_symbols = lower + upper + digits + specials

        key_sum = sum(ord(c) for c in key)

        decrypted = ''
        for c in text:
            if c in all_symbols:
                idx = all_symbols.index(c)
                d_idx = (idx - key_sum) % len(all_symbols)
                decrypted += all_symbols[d_idx]
            else:
                decrypted += c
        return decrypted

    def acquire(self, timeout=None):
        end_time=None
        if timeout is not None:
            logger.info(f"timeout {timeout}")
            end_time=time.time() + timeout

        while True:
            with self._lock:
                if self._pool:
                    conn = self._pool.pop()
                    self._in_use.add(id(conn))
                    logger.info("Return connection from step 1")
                    return conn

                if len(self._in_use) < self._maxsize:
                    conn = self._creator()
                    self._in_use.add(id(conn))
                    logger.info("Return connection from step 2")
                    return conn
            logger.info(f"Backup connection size {len(self._pool)}")
            if end_time is not None and time.time() > end_time and len(self._pool)==1:
                logger.info(f"End time {end_time}")
                logger.info(f"Current time {time.time()}")
                raise TimeoutError("Connection pool timeout")
            time.sleep(0.01)

    def release(self, conn):
        with self._lock:
            self._in_use.discard(id(conn))
            self._pool.append(conn)

    def close_all(self):
        with self._lock:
            for conn in list(self._pool):
                try:
                    conn.close()
                finally:
                    self._pool.remove(conn)
            for cid in list(self._in_use):
                # We may need a way to map id->connection; implement if available
                pass

#Usages
param='qmark'
logger.info("Initiating crateDB connection")
pool = SimpleConnectionPool(create_crate_connection, maxsize=8, param=param)

def select_messages(message_id):
    logger.info(f"Select messages respective to {message_id} for generating summary")
    try:
        conn = pool.acquire(timeout=5)
        cursor = conn.cursor()
        crate_schema_name = cursor.connection.client.schema
        select_content_query=f"""SELECT content from {crate_schema_name}.messages where message_id=? ORDER BY timestamp DESC"""
        cursor.execute(select_content_query, (message_id,))
        all_contents=cursor.fetchall()
        print(all_contents)
        result = " ".join(item[0] for item in all_contents)
        return result
    except ConnectTimeoutError:
        logger.error(f"Error occur when inserting company details ")
    except ReadTimeoutError:
        logger.info('Read timeout: server did not respond within timeout period')
    except Exception as e:
        logger.info(f"{e}")
    finally:
        pool.release(conn)
    

def insert_messages(message_body,message_id):
    logger.info("Event data inserting into CrateDB database.")
    try:
        conn = pool.acquire(timeout=5)
        cursor = conn.cursor()
        crate_schema_name = cursor.connection.client.schema
        chat_id = "1" #Need to work 
        sender_id="+11111111" #Need to work
        content=message_body['user_text']
        media_url="http://wwww.aaaa.com/abcd.jpg" #Need to work
        message_type="Text" #Need to capture from AWS comprehend response/
        status="u" #User type
        sentiment=message_body['sentiment']
        entities=message_body['entities']
        from datetime import datetime, timezone
        utc = datetime.now(timezone.utc)
        params=(message_id, 
                chat_id,
                sender_id,
                content,
                media_url,
                message_type,
                status,
                sentiment,
                entities,
                utc)
        insert_sql=f"""insert into {crate_schema_name}.messages (message_id, chat_id, sender_id,
        content, media_url, message_type, status, sentiment, entities, timestamp) values (?,?,?,?,?,?,?,?,?,?)"""
        cursor.execute(insert_sql, params)
        logger.info("Chat details inserted successfully")
    except ConnectTimeoutError:
        logger.error(f"Error occur when inserting company details ")
    except ReadTimeoutError:
        logger.info('Read timeout: server did not respond wihtin timeout period')
    except Exception as e:
        logger.info(f"{e}")
    finally:
        pool.release(conn)
    
