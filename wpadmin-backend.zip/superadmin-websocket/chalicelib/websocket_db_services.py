from datetime import datetime

import chalicelib.crate_db_operation as db_opr_service
import json
import os
from typing import Any, Dict, Optional, List, Tuple
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

#ThreadSafe implementation of Dict for storing all real-time users
class LambdaThreadSafeDictForRealTimeUsers:
    """
    Thread-safe dictionary for AWS Lambda using /tmp/ file storage + in-memory cache.
    Safe across concurrent invocations (with eventual consistency).
    Uses Lambda's /tmp/ directory (ephemeral per invocation, but concurrent-safe).
    """

    def __init__(self, filename: str = '/tmp/lambda_dict.json', max_memory_gb: float = 0.4, event_connection=None):
        self.filename = filename
        self.event_connection=event_connection
        self._data: Dict[Any, Any] = {}
        self._lock = None  # Single-threaded per Lambda invocation
        self.max_memory_gb = max_memory_gb
        self._load()

    def _load(self) -> None:
        """Load from /tmp/ file if exists"""
        try:
            if os.path.exists(self.filename):
                with open(self.filename, 'r') as f:
                    file_data = json.load(f)
                    self._data = {str(k): v for k, v in file_data.items()}  # Keys as str for JSON
                print(f"Loaded {len(self._data)} items from {self.filename}")
        except Exception as e:
            print(f"Load failed: {e}")

    def _save(self) -> None:
        """Save to /tmp/ file atomically"""
        try:
            tmp_file = self.filename + '.tmp'
            with open(tmp_file, 'w') as f:
                json.dump(self._data, f)
            os.replace(tmp_file, self.filename)  # Atomic move
        except Exception as e:
            print(f"Save failed: {e}")

    def _check_memory(self) -> bool:
        """Check if memory usage is acceptable"""
        size_mb = len(json.dumps(self._data).encode()) / (1024 * 1024)
        return size_mb < (self.max_memory_gb * 1024)

    def __getitem__(self, key: Any) -> Any:
        return self._data[str(key)]

    def __setitem__(self, key: Any, value: Any) -> None:
        self._data[str(key)] = value
        if not self._check_memory():
            self._save()  # Flush if memory tight

    def get(self, key: Any, default: Any = None) -> Any:
        return self._data.get(str(key), default)

    def pop(self, key: Any, default: Any = None) -> Any:
        k = str(key)
        result = self._data.pop(k, default)
        self._save()
        return result

    def __contains__(self, key: Any) -> bool:
        return str(key) in self._data

    def __len__(self) -> int:
        return len(self._data)

    def clear(self) -> None:
        self._data.clear()
        try:
            os.remove(self.filename)
        except:
            pass

    def items(self) -> List[Tuple[str, Any]]:
        return list(self._data.items())

    def all_keys(self):
        keys = [key for key in self._data.keys()]
        return keys

    def flush(self) -> None:
        """Force save to disk"""
        self._save()

    def close(self) -> None:
        """Save and cleanup"""
        self.flush()

    def insert_real_time_user_in_cache(self):
        pass


def reset_realtime_agents_presence():
    logger.info(f"Inside reset_realtime_agents_presence for starting operation")
    try:
        db_opr_service.reset_realtime_agent_table()
    except Exception as e:
        logger.error()
def get_agent_connection_id(empersendid):
    logger.info(f"Getting connection ID for sending notification")
    try:
        query=f"""select user_id, connection_id from crate.ws_connections where customer_contact_number=? limit 1"""
        connections=db_opr_service._execute(query, (empersendid,), True)
        logger.info(f"Connection details {connections}")
        return connections
    except Exception as e:
        logger.error(f"Error in getting connection id {e}")


def _insert_params(connection_id, data):
    logger.info("Insert operation _insert_params")
    db_opr_service.wsinsert(connection_id, data)

def list_connections(user_cache):
    return user_cache.all_keys()

def insert_data_in_cache(customer_contact_number,message_id, agent_id, userId,  users_cache):
    logger.info(f"customer_contact_number ={customer_contact_number}")
    import time
    if users_cache.get(customer_contact_number):
        user_result=users_cache.pop(message_id)
        users_cache[message_id]= { 'customer_contact_number':customer_contact_number, 'is_active':"Y", "active_since": str(time.time()), "agent_id": agent_id, "user_id": userId}
    else:
        users_cache[message_id] = {'customer_contact_number':customer_contact_number,'is_active': "Y", "active_since": str(time.time()), "agent_id": agent_id, "user_id": userId}
    logger.info("Insert or update cache with new user into cache")


def insert_data_create(record):
    db_opr_service.insert_data(record)
    print("insert record Done")

def _execute(query, params=None, fetch=False):
    logger.info(f"Initiating WebSocket through _execute {fetch}")
    all_active_users=db_opr_service._execute(query=query,params=params, fetch=fetch)
    return all_active_users
def _execute_on_redis(connection_id, param):
    db_opr_service._execute_on_redis(connection_id=connection_id, params=param)

def _execute_on_redis_for_update(connection_id, existing_connection_id, existing_client_object):
    db_opr_service._update_on_redis(connection_id, existing_connection_id, existing_client_object)


def save_active_connection_in_redis(Item):
    pass

def create_new_connection(Item: dict):
    try:
        connection_id = Item.get('connection_id')
        agent_id = Item.get('agent_id')
        customer_number = Item.get('customer_number')
        user_type = Item.get('user_type')
        logger.info(f"Saving WebSocket Connection for {connection_id} and agent {agent_id} and Customer {customer_number}")

        sql=f"""SELECT connection_id, user_id, customer_contact_number FROM crate.ws_connections_suervisor where user_id=? and 
                            disconnected_at is NULL and user_type='E' and customer_contact_number=?"""
        all_connection_ids_agent = _execute(sql, (agent_id, customer_number,), True)
        if len(all_connection_ids_agent)>0:
            DELETE_SUPER="DELETE FROM crate.ws_connections WHERE user_id=? AND customer_contact_number=? "
            _execute(DELETE_SUPER, (agent_id,customer_number,), False)
            SQL_INSERT = f"""INSERT INTO crate.ws_connections_suervisor (connection_id, user_id, connected_at, customer_contact_number, user_type)
                                        VALUES (?, ?, ?, ?,?)"""
            from datetime import datetime, timezone
            utc = datetime.now(timezone.utc)
            _execute(SQL_INSERT, (connection_id, agent_id, utc, customer_number, user_type,), False)
            super_object = {
                "agent_id": agent_id,
                "message_id": all_connection_ids_agent[0][3],
                "connection": connection_id,
                "is_active": 0
            }
            _execute_on_redis(customer_number, super_object)
            return True
        else:
            SQL_INSERT = f"""INSERT INTO crate.ws_connections (connection_id, user_id, connected_at, customer_contact_number, user_type,messageid)
                                                        VALUES (?, ?, ?, ?,?,?)"""
            from datetime import datetime, timezone
            utc = datetime.now(timezone.utc)
            _execute(SQL_INSERT,
                     (connection_id, agent_id, utc, customer_number, user_type,'demo'),
                     False)
            super_object = {
                "agent_id": agent_id,
                "message_id": "",
                "connection": connection_id,
                "is_active": 0
            }
            _execute_on_redis(customer_number, super_object)
            return True
    except Exception as e:
        logger.error({e})

def save_connection_updates(Item: dict):
    try:
        connection_id=Item.get('connection_id')
        agent_id=Item.get('agent_id')
        customer_number= Item.get('customer_number')
        user_type=Item.get('user_type')
        logger.info(f"Saving WebSocket Connection for {connection_id} and agent {agent_id} and Customer {customer_number}")

        if user_type=='S': #Supervisor
            logger.info(f"Establishing connection for Superviosr {agent_id}")
            from datetime import datetime, timezone
            utc = datetime.now(timezone.utc)
            DELETE_SUPER="DELETE from crate.ws_connections where user_id=?"
            _execute(DELETE_SUPER, (agent_id,), False)
            SQL_INSERT = f"""INSERT INTO crate.ws_connections (connection_id, user_id, connected_at, customer_contact_number, user_type)
                            VALUES (?, ?, ?, ?,?) ON CONFLICT (connection_id, user_id) DO NOTHING"""
            _execute(SQL_INSERT, (connection_id, agent_id, utc, customer_number, user_type), False)
            super_object = {
                "agent_id": agent_id,
                "message_id": "",
                "contact_number": customer_number,
                "is_active": 0
            }
            _execute_on_redis(connection_id, super_object)
            return True

        SQL_SELECT_AGENT =f"""SELECT connection_id, user_id, customer_contact_number, messageid from crate.ws_connections
                        WHERE connected_at >= CURRENT_TIMESTAMP - INTERVAL '60' MINUTE and user_id=? and disconnected_at is NULL and user_type='E'"""
        #SQL_SELECT_AGENT=f"""SELECT connection_id, user_id, customer_contact_number FROM crate.ws_connections WHERE user_id=?"""
        all_connection_ids_agent=_execute(SQL_SELECT_AGENT,(agent_id,), True)

        if len(all_connection_ids_agent)>4: #One Agent can handle max 5 customers
            logger.info(f"Agent {agent_id} has already connected with 5 customers")
            logger.info("Can't assign new customer to this agent {agent_id}")
            for existing_agent in all_connection_ids_agent:
                existing_connection_id=existing_agent[0]
                existing_agent_id=existing_agent[1]
                existing_customer_contact_number=existing_agent[2]
                existing_message_id=existing_agent[3]

                if existing_customer_contact_number==customer_number:
                    SQL_UPDATE_CONNECTION="UPDATE crate.ws_connections SET connection_id=?, last_seen=now() WHERE user_id=? AND customer_contact_number=?"
                    existing_client_object={
                        "agent_id": agent_id,
                        "message_id": existing_message_id,
                        "contact_number": customer_number,
                        "is_active":0
                    }
                    _execute_on_redis_for_update(connection_id, existing_connection_id, existing_client_object)
                    _execute(SQL_UPDATE_CONNECTION, (connection_id,existing_connection_id,agent_id,customer_number, ),False)
                    return True
            return False
        else:
            is_updated=True
            for existing_agent in all_connection_ids_agent:
                existing_connection_id = existing_agent[0]
                existing_agent_id = existing_agent[1]
                existing_customer_contact_number = existing_agent[2]
                existing_message_id = existing_agent[3]
                if existing_message_id is None:
                    existing_message_id=""

                if existing_customer_contact_number==customer_number:
                    existing_client_object = {
                        "agent_id": agent_id,
                        "message_id": existing_message_id,
                        "contact_number": customer_number,
                        "is_active": 0
                    }
                    _execute_on_redis_for_update(connection_id, existing_connection_id, existing_client_object)
                    SQL_UPDATE_CONNECTION = "DELETE FROM crate.ws_connections WHERE user_id=? and connection_id=?"
                    _execute(SQL_UPDATE_CONNECTION, (agent_id, existing_connection_id,), False)
                    is_updated=True
                    break

            if is_updated:
                logger.info(f"Establishing connection for agent {agent_id}")
                from datetime import datetime, timezone
                utc = datetime.now(timezone.utc)
                SQL_INSERT=f"""INSERT INTO crate.ws_connections (connection_id, user_id, connected_at, customer_contact_number, user_type)
                VALUES (?, ?, ?, ?,?) ON CONFLICT (connection_id, user_id) DO NOTHING"""
                _execute(SQL_INSERT, (connection_id, agent_id, utc, customer_number,user_type),False)
                client_objects = {
                    "agent_id": agent_id,
                    "message_id": '',
                    "customer_number" : customer_number,
                    "is_active": 1   #0->False->Occupied by a customer, 1->True->Available to Serve
                }
                _execute_on_redis(connection_id,client_objects )
                logger.info("New connection established")
            return True
    except Exception as e:
        logger.error(f"Error occured when creating new WebSocket Connection {e}")
        return False


#DB operations
def save_connection(Item: dict):
    try:
        connection_id = Item.get('connection_id')
        agent_id=Item.get('agent_id')
        logger.info(f"Saving WebSocket Connection {connection_id}")
        SQL_SELECT_AGENT="SELECT connection_id, user_id FROM crate.ws_connections WHERE user_id=? limit 1"
        all_connection_ids_agent=_execute(SQL_SELECT_AGENT,(agent_id,), True)
        if len(all_connection_ids_agent)==0:
            SQL_INSERT=f"""INSERT INTO crate.ws_connections (connection_id, user_id, connected_at)
            VALUES (?, ?, now())
            ON CONFLICT (connection_id, user_id) DO NOTHING"""
            _execute(SQL_INSERT, (connection_id,agent_id,),False)
        else:
            existing_connection_id=all_connection_ids_agent[0][0] #[['connection-01','agent-01']]
            existing_agent_id=all_connection_ids_agent[0][1]
            logger.info(f"Agent {existing_agent_id} with connection id {existing_connection_id} is already connected. Updating the agent with current connection")
            #Update connection_id in the ws_connection table.
            UPDATE_CONN_QUERY=f"""UPDATE crate.ws_connections set connection_id=?, new_updated_at=now() where user_id=?"""
            _execute(UPDATE_CONN_QUERY,(connection_id, agent_id,),False)
            logger.info(f"Connection updated for agebt {agent_id}")

    except Exception:
        logger.error("Error occured when creating new WebSocket Connection")


def make_agent_re_available(connection_id, agent_id):
    try:
        logger.info(f"Agent ID {agent_id} is making ONLINE again.")
        sql_agent_avail_again="UPDATE crate.realtime_agents_presence SET status=? WHERE agent_id=?"
        params=(True, agent_id,)
        sql_complete_previous_againt_availability="UPDATE crate.messageid_agents SET session_end=now() WHERE agent_id=?"
        params_previsous=(agent_id,)
        sql_delete_previous_connection=f"""DELETE FROM crate.ws_connections WHERE connection_id=? and user_id=?"""
        params_delete_connection=(connection_id,agent_id,)
        from concurrent.futures import ThreadPoolExecutor
        with ThreadPoolExecutor(max_workers=3) as executor:
            f1 = executor.submit(_execute, sql_agent_avail_again, params, False)
            f2 = executor.submit(_execute, sql_complete_previous_againt_availability,params_previsous, False)
            f3 = executor.submit(_execute, sql_delete_previous_connection,params_delete_connection, False)
            result1 = f1.result()
            result2 = f2.result()
            result3 = f3.result()
            logger.info(f"Agent is available again to get new customer {agent_id}")
        
        # _execute(sql_agent_avail_again, (True, agent_id,), False)    
        # _execute(sql_complete_previous_againt_availability, (agent_id,), False)

    except Exception:
        logger.error("Not able to get Agent for message communication")
#Get Unique Agent ID
def get_agent_on_connection(agent_id: str):
    try:
        logger.info(f"Agent ID {agent_id} is getting for receiving message")
        SELECT_AGENT_ID="SELECT user_id, connection_id FROM crate.ws_connections WHERE user_id=?"
        agent_connection_id=_execute(SELECT_AGENT_ID, (agent_id,), True)
        print(type(agent_connection_id))
        print(agent_connection_id)
        return agent_connection_id[0][0], agent_connection_id[0][1] #agent_id, connection_id
    except Exception:
        logger.error("Not able to get Agent for message communication")

def delete_connection(Item: dict):
    try:
        connection_id = Item.get('connection_id')
        agent_id = Item.get('agent_id')
        logger.info(f"Deleting Connection Connection ID {connection_id} Agent {agent_id}")
        make_agent_re_available(connection_id=connection_id, agent_id=agent_id)
        logger.info(f"Connection {connection_id} is deleted for agent {agent_id}")
    except Exception as e:
        logger.error("Error occured when deleteing existing WebSocket Connection {e}")

def get_supervisor_connection():
    logger.info(f"Get Supervisor connection Details")
    SQL_SUPERVISOR_CONNECTION=f"""SELECT connection_id FROM crate.ws_connections where user_type='S' and user_id='supervisor1' limit 1"""
    rows=_execute(SQL_SUPERVISOR_CONNECTION, fetch=True)
    print(rows[0])
    if rows[0] is None:
        return []
    return rows[0]

def list_connections(agent_id, message_id):
    logger.info(f"List all connected agent_id {agent_id} and {message_id}")
    SQL_SELECT=f"""SELECT connection_id FROM crate.ws_connections where user_id=? and messageid=?"""
    rows=_execute(SQL_SELECT, (agent_id,message_id,), fetch=True)
    if rows is None:
        return []
    return [row[0] for row in rows]

def list_usernames():
    logger.info(f"List all user names")
    SQL_SELECTS=f"""SELECT username FROM crate.users ORDER BY created_at ASC"""
    rows=_execute(SQL_SELECTS, fetch=True)
    if rows is None:
        return []

    #return [row['username'] for row in rows]
    usernames=set()
    for row in rows:
        usernames.add(row[0])
    return list(usernames)

def _send_error(app, connection_id: str, error_type_str: str, error_message:str ):
    logger.error(f"Error")
    return {
        "type" : "error",
        "code": error_type_str,
        "message" : error_message
    }
    
def _handle_get_users(connection_id:str):
    logger.info(f"Handling Get Users")
    usernames=list_usernames()
    payload = { 
        "type": "users",
        "count" : len(usernames),
        "items": usernames
    }
    return payload