
import threading
import time
import datetime
from sqlite3 import sqlite_version
from urllib3.exceptions import ConnectTimeoutError, ReadTimeoutError
#from urllib3.exceptions import ConnectTimeoutError, ReadTimeoutError
import logging
import urllib3
from crate import client
import math
import string
import logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)
import redis
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def create_redis_connection():
    print("Getting Redis Connection Pool")
    redis_pool = redis.ConnectionPool(
        host='',
        port=12391,
        password="",
        db=0,
        username="default",
        max_connections=10,  # keep small for Lambda
        socket_connect_timeout=2,
        socket_timeout=2,
        decode_responses=True  # returns str instead of bytes
    )
    redis_client = redis.Redis(connection_pool=redis_pool)
    return redis_client

def create_crate_connection():
    return client.connect(
        servers=[""],
        username="admin",
        password= "",
        timeout=urllib3.Timeout(connect=5.0,read=10.0),
        schema="crate",
        verify_ssl_cert=True,

    )

class RedisConnectionPool:
    def __init__(self, creator):
        self._creator = creator
        self._pool = []
        self._in_use = set()

    def acquire(self,timeout=None):
        client=self._creator()
        self._in_use.add(client)
        return client
    
class SimpleConnectionPool:
    def __init__(self, creator, maxsize=10, **param):
        self._creator = creator
        self._maxsize=maxsize
        self._lock=threading.Lock()
        self._pool = []
        self._in_use = set()
        self._param=param

    def encrypt(self, unencrypted_text, key):
        # Define character groups
        lower = string.ascii_lowercase
        upper = string.ascii_uppercase
        digits = string.digits
        specials = string.punctuation
        all_symbols = lower + upper + digits + specials

        key_sum = sum(ord(c) for c in key)  # derive a numeric key for shifting

        encrypted = ''
        for c in unencrypted_text:
            if c in all_symbols:
                idx = all_symbols.index(c)
                # Deterministic (but not secure) shift
                e_idx = (idx + key_sum) % len(all_symbols)
                encrypted += all_symbols[e_idx]
            else:
                encrypted += c  # leave other chars unchanged
        return encrypted

    def decrypt(self, text, key):
        lower = string.ascii_lowercase
        upper = string.ascii_uppercase
        digits = string.digits
        specials = string.punctuation
        all_symbols = lower + upper + digits + specials

        key_sum = sum(ord(c) for c in key)

        decrypted = ''
        for c in text:
            if c in all_symbols:
                idx = all_symbols.index(c)
                d_idx = (idx - key_sum) % len(all_symbols)
                decrypted += all_symbols[d_idx]
            else:
                decrypted += c
        return decrypted

    def acquire(self, timeout=None):
        end_time=None
        if timeout is not None:
            logger.info(f"timeout {timeout}")
            end_time=time.time() + timeout

        while True:
            with self._lock:
                if self._pool:
                    conn = self._pool.pop()
                    self._in_use.add(id(conn))
                    logger.info("Return connection from step 1")
                    return conn

                if len(self._in_use) < self._maxsize:
                    conn = self._creator()
                    self._in_use.add(id(conn))
                    logger.info("Return connection from step 2")
                    return conn
            logger.info(f"Backup connection size {len(self._pool)}")
            if end_time is not None and time.time() > end_time and len(self._pool)==1:
                logger.info(f"End time {end_time}")
                logger.info(f"Current time {time.time()}")
                raise TimeoutError("Connection pool timeout")
            time.sleep(0.01)

    def release(self, conn):
        with self._lock:
            self._in_use.discard(id(conn))
            self._pool.append(conn)

    def close_all(self):
        with self._lock:
            for conn in list(self._pool):
                try:
                    conn.close()
                finally:
                    self._pool.remove(conn)
            for cid in list(self._in_use):
                # We may need a way to map id->connection; implement if available
                pass

#Usages
param='qmark'
print("Initiating crateDB connection")
pool = SimpleConnectionPool(create_crate_connection, maxsize=8, param=param)
redis_pool_obj=RedisConnectionPool(create_redis_connection)


################WebSocket Operation#################################
def _init_tables(self):
    self.cursor.execute("""
    CREATE TABLE IF NOT EXISTS crate.ws_connections (
        connection_id STRING PRIMARY KEY
    )
    """)

    self.cursor.execute("""
    CREATE TABLE IF NOT EXISTS crate.realtime_data (
        value DOUBLE,
        timestamp TIMESTAMP
    )
    """)

# ----------------------
# WebSocket connections
# ----------------------
def save_connection(self, connection_id):
    self.cursor.execute(
        "INSERT INTO crate.ws_connections (connection_id) VALUES (?)",
        (connection_id,)
    )

def remove_connection(self, connection_id):
    self.cursor.execute(
        "DELETE FROM crate.ws_connections WHERE connection_id = ?",
        (connection_id,)
    )

def list_connections(self):
    self.cursor.execute("SELECT connection_id FROM crate.ws_connections")
    return [row[0] for row in self.cursor.fetchall()]


# --------------------
# Data storage
# --------------------
def insert_data(record):
    logger.info(f"Initiating push message insert to websocket Users")
    conn = pool.acquire(timeout=5)
    try:
        cursor=conn.cursor()
        cursor.execute(
        "INSERT INTO crate.realtime_data (value, timestamp) VALUES (?, ?)",
        (record["value"], record["timestamp"]))
        # sql_messages=f"""insert into crate.messages (message_id,sender_id, content, message_type, status, sentiment, entities, timestamp, tenant_id,
        # conversation_id, direction, provider_message_id)
        # values (?,?,?,?,?,?,?,?,?,?,?,?)"""
        #params = ()
    except ConnectTimeoutError:
        logger.error(f"Error occur when inserting company details ")
    except ReadTimeoutError:
        logger.info('Read timeout: server did not respond within timeout period')
    except Exception as e:
        logger.info(f"{e}")
    finally:
        pool.release(conn)


def wsinsert(connection_id, data):
    logger.info(f"Initating websocket Users")
    conn = pool.acquire(timeout=5)
    try:
        cursor = conn.cursor()
        cursor.execute(
            "INSERT INTO crate.wsmessage (connection_id, message, timestamp) VALUES (?, ?, ?)",
            (connection_id, data, datetime.utcnow())
        )
        conn.commit()
        print("inserted values............")
    except ConnectTimeoutError:
        logger.error(f"Error occur when inserting company details ")
    except ReadTimeoutError:
        logger.info('Read timeout: server did not respond within timeout period')
    except Exception as e:
        logger.info(f"{e}")
    finally:
        pool.release(conn)


def _insert_ws_msg(msg):
    logger.info(f"Initating websocket Users")
    conn = pool.acquire(timeout=5)
    try:
        cur=conn.cursor()
        SQL_INSERT_USERS="insert into crate.users (id, username, created_at) values (?,?,?)"
    except ConnectTimeoutError:
        logger.error(f"Error occur when inserting company details ")
    except ReadTimeoutError:
        logger.info('Read timeout: server did not respond within timeout period')
    except Exception as e:
        logger.info(f"{e}")
    finally:
        pool.release(conn)

def delete_connection(connection_id):
    redis_conn=redis_pool_obj.acquire(timeout=10)
    pipe = redis_conn.pipeline(transaction=True)

    pipe.delete(connection_id)
    pipe.srem("active_connections", connection_id)
    pipe.srem("inactive_connections", connection_id)

    pipe.execute()

def _update_on_redis(connection_id, existing_connection_id, existing_client_object):
    try:
        logger.info(f"Deleting Connection ID {connection_id}")
        redis_conn = redis_pool_obj.acquire(timeout=10)
        key = existing_connection_id
        LUA_SCRIPT_DELETE_CONNECTION_ID_FRM_CACHE = f"""
                        local key = KEYS[1]
                        if redis.call("EXISTS", key) == 1 then
                            redis.call("DEL", key)
                            return 1
                        else
                            return 0
                        end
                """
        result = redis_conn.eval(
            LUA_SCRIPT_DELETE_CONNECTION_ID_FRM_CACHE,
            1,
            key
        )
        if result==1:
            print(f"Connection ID {key} is deleted.")
        new_key=    connection_id
        NEW_LUA_SCRIPT = """
                    local key = KEYS[1]
                    if redis.call("EXISTS", key) == 0 then
                        redis.call("HSET", key, unpack(ARGV))
                        return 1
                    else
                        return 0
                    end
                    """
        argv = []
        for k, v in existing_client_object.items():
            argv.extend([k, v])
        result = redis_conn.eval(
            NEW_LUA_SCRIPT,
            1,  # number of KEYS
            new_key,  # KEYS[1]
            *argv  # ARGV[1]
        )

        NEW_ACTIVE_LUA_SCRIPT = """
                            local key = KEYS[1]
                            local field = ARGV[2]
                            local value = ARGV[3]
                            
                            if redis.call("EXISTS", key) == 0 then
                                redis.call("HSET", key, field, value)
                                return 1
                            else
                                return 0
                            end
                            """
        argv = []
        result = redis_conn.eval(
            NEW_ACTIVE_LUA_SCRIPT,
            1,
            "active_connections",
            connection_id,
            "1"
        )
        print(result)
        LUA_SCRIPT_DEL_CONNECTION_ID_INACTIVE_SET = """
                    local set_key = KEYS[1]
                    local member = ARGV[1]
                    
                    if redis.call("SISMEMBER", set_key, member) == 1 then
                        redis.call("SREM", set_key, member)
                        return 1
                    else
                        return 0
                    end
                    """
        deleted = redis_conn.eval(
            LUA_SCRIPT_DEL_CONNECTION_ID_INACTIVE_SET,
            1,
            "active_connections",
            existing_connection_id
        )
        print(f"Deleted from inactive set key {key} = {deleted}")
    except Exception as e:
        logger.error(f"Error occured when updating key {existing_connection_id} in Cache")

def _execute_on_redis(connection_id, params):
    try:
        # redis_conn.hset(connection_id, mapping=params)
        # redis_conn.sadd("active_connections", connection_id)
        # redis_conn.srem("inactive_connections", connection_id)
        redis_conn=redis_pool_obj.acquire(timeout=10)
        pipe = redis_conn.pipeline(transaction=True)
        # store main record
        pipe.hset(
            connection_id,
            mapping=params
        )
        # maintain indexes
        pipe.sadd("active_connections", connection_id)
        pipe.srem("inactive_connections", connection_id)
        pipe.execute()
        logger.info("Inserted new Connection in Redis")

    except Exception as e:
        logger.error(f"Error occured when inserting data in Redis {e}")


def reset_realtime_agent_table():
    pass

def _execute(query, params, fetch=False):
    logger.info(f"Executing {query} SQL query for websocket Users")
    conn = pool.acquire(timeout=5)
    try:
        cur=conn.cursor()
        cur.execute(query, params or ())
        if fetch:
            return cur.fetchall()
        return None
    except ConnectTimeoutError:
        logger.error(f"Error occur when executing query {query}")
    except ReadTimeoutError:
        logger.error('Read timeout: server did not respond within timeout period')
    except Exception as e:
        logger.error(f"{e}")
    finally:
        pool.release(conn)

#########################
def insert_messages(message_body,message_id):
    logger.info("Event data inserting into CrateDB database.")
    try:
        conn = pool.acquire(timeout=5)
        cursor = conn.cursor()
        crate_schema_name = cursor.connection.client.schema
        chat_id = "1" #Need to work 
        sender_id="+11111111" #Need to work
        content=message_body['user_text']
        media_url="http://wwww.aaaa.com/abcd.jpg" #Need to work
        message_type="Text" #Need to capture from AWS comprehend response/
        status="u" #User type
        sentiment=message_body['sentiment']
        entities=message_body['entities']
        from datetime import datetime, timezone
        utc = datetime.now(timezone.utc)
        params=(message_id, 
                chat_id,
                sender_id,
                content,
                media_url,
                message_type,
                status,
                sentiment,
                entities,
                utc)
        insert_sql=f"""insert into {crate_schema_name}.messages (message_id, chat_id, sender_id,
        content, media_url, message_type, status, sentiment, entities, timestamp) values (?,?,?,?,?,?,?,?,?,?)"""
        cursor.execute(insert_sql, params)
        logger.info("Chat details inserted successfully")
    except ConnectTimeoutError:
        logger.error(f"Error occur when inserting company details ")
    except ReadTimeoutError:
        logger.info('Read timeout: server did not respond wihtin timeout period')
    except Exception as e:
        logger.info(f"{e}")
    finally:
        pool.release(conn)
    
