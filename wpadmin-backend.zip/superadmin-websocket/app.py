from chalice import Chalice
from chalice import Chalice, CORSConfig
from chalicelib.websocket_service import WebSocketService
import chalicelib.websocket_db_services as ws_opr_service
import logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

app = Chalice(app_name='superadmin-websocket')
app.debug = True

# CORS Support
cors_config = CORSConfig(
    allow_origin='*',
    allow_headers=['X-Special-Header', 'Content-Type', 'Authorization'],
    max_age=600,
    expose_headers=['X-Special-Header'],
    allow_credentials=True
)

ws_service = WebSocketService(ws_opr_service)

app.experimental_feature_flags.update([
    'WEBSOCKETS'
])

@app.on_ws_connect()
def on_connect(event):
    event_dict = event.to_dict()
    logger.info(f"Connecting to Wss {event_dict}")
    connection_id = event.connection_id
    qs_params = event_dict.get("queryStringParameters") or {}
    print(qs_params)
    return {"statusCode": 200}

@app.on_ws_disconnect()
def on_disconnect(event):
    try:
        event_dict = event.to_dict()
        logger.info(f"Disconnecting Wss {event_dict} Preparing on_disconnect method {event.connection_id}")
        connection_id = event.connection_id
        qs_params = event_dict.get("queryStringParameters") or {}
        contact_customer_number=qs_params.get("")
        user_type = qs_params.get("usertype")
        if user_type is None:
            user_type = 'E'
        if user_type == 'E':
            customer_number = qs_params.get("empresaID")
            agent_id = qs_params.get("agentId")
        else:
            customer_number = "00000000"
            agent_id = qs_params.get("agentId")

        logger.info(f"Deleting Agent ID: {agent_id}")
        if not agent_id:
            from chalice import WebsocketDisconnectedError
            raise WebsocketDisconnectedError("Required agentId")

        # agent_id = event.query_string_parameters.get("agentId")
        logger.info(f"Agent ID {agent_id}")
        if not agent_id:
            raise Exception("agent_id is required")
        Item = {
            'agent_id': agent_id,
            'connection_id': connection_id,
            'customer_number': customer_number,
            'user_type': user_type
        }

        is_connection = ws_opr_service.create_new_connection(Item)
        if is_connection:
            logger.info("Established new connection for agent {agent_id} successfully")
        else:
            raise Exception("No slot available for new connection.")
        import time
        time.sleep(1)
        logger.info("Exiting on_connect")
        return {"statusCode": 200}
    except Exception as e:
        logger.error(f"Error {e}")
        return {"statusCode": 500}

@app.on_ws_message()
def on_message(event):
    logger.info("Initiating on_message in websocket")
    try:
        event_dict = event.to_dict()
        logger.info(f"Messages Wss {event_dict}")
        qs_params = event_dict.get("queryStringParameters") or {}
    except Exception as e:
        logger.error(f"Error {e}")


@app.route('/')
def index():
    return {'hello': 'world'}


@app.route('/reset')
def index():
    logger.info(f"Reseting initated for testing.")
    try:
        logger.info(f"Clearing crate.realtime_agents_presence  database")
        ws_opr_service.reset_realtime_agents_presence()

    except Exception as e:
        logger.error(f"Exception occured when resetting the database")


@app.route('/send', methods=['POST'], cors=cors_config)
def publish():
    """
    Push data to all connected websocket clients
    """
    payload = app.current_request.json_body
    logger.info(f"Record received for user {payload} type: {type(payload)}")
    try:
        list_of_active_connections=[]
        empersendid = payload.get('empersendid')
        supervisor_message = payload.get('text')
        logger.info(f"record = {payload}")
        connections= ws_opr_service.get_agent_connection_id(empersendid=empersendid)
        logger.info(f"Agent ID {connections[0][0]} Connection id: {connections[0][1]}")

        list_of_active_connections.append(connections[0][1]) #Connection ID
        # Broadcast to WebSocket
        ws_service.broadcast({
            "type": "data",
            "payload": payload
        }, list_of_active_connections)
        logger.info(f"Message send to Customer {empersendid}")

    except Exception as e:
        logger.error(f"Error sending message to websocket to UI. {e}")
        return {
            "status": "failed"
        }
    return {"status": "sent"}

# The view function above will return {"hello": "world"}
# whenever you make an HTTP GET request to '/'.
#
# Here are a few more examples:
#
# @app.route('/hello/{name}')
# def hello_name(name):
#    # '/hello/james' -> {"hello": "james"}
#    return {'hello': name}
#
# @app.route('/users', methods=['POST'])
# def create_user():
#     # This is the JSON body the user sent in their POST request.
#     user_as_json = app.current_request.json_body
#     # We'll echo the json body back to the user in a 'user' key.
#     return {'user': user_as_json}
#
# See the README documentation for more examples.
#
